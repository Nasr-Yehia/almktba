<?php
/**
* @ iDezender 7.0
* @ Developed by Qarizma
*
* @    Visit our website:
* @    www.iRadikal.com
* @    For cheap decoding service :)
* @    And for the ionCube Decoder!
*/          

	function e_error($comm = '', $comm2 = '') {
		echo '<br>
<table style="width: 74%; border: 1px solid #FF0000; background-color: #FFFF00; height: 77px;" cellspacing="0" cellpadding="0" align="center" dir=ltr>
	<tr>
		<td style="text-align: center">';
		echo '<s';
		echo 'pan style="color: #008000">
		<table style="width: 90%">
			<tr>
					<td style="text-align: right; color: #FF0000; width: 100%"dir=rtl >';
		echo '<s';
		echo 'pan style="color: #FF0000">';
		echo '<s';
		echo 'trong>';
		echo $comm;
		echo ' 
	</strong></span></td>
				<td>';
		echo '<s';
		echo 'pan style="color: #FF0000">';
		echo '<s';
		echo 'trong>
				<img alt="" src="images/erro.gif" ></strong></span></td>
			</tr>
		</table>
		</span></td>
	</tr>
</table>
<br>

';
	}

	function e_ok($comm = '') {
		echo '<br>
<table style="width: 74%; border: 1px solid #FF0000; background-color: #FFFF00; height: 77px;" cellspacing="0" cellpadding="0" align="center" dir=ltr>
	<tr>
		<td style="text-align: center">';
		echo '<s';
		echo 'pan style="color: #008000">
		<table style="width: 90%">
			<tr>
					<td style="text-align: right; color: #FF0000; width: 100%"dir=rtl >';
		echo '<s';
		echo 'pan style="color: #008000">';
		echo '<s';
		echo 'trong>';
		echo $comm;
		echo ' 
	</strong></span></td>
				<td>';
		echo '<s';
		echo 'pan style="color: #FF0000">';
		echo '<s';
		echo 'trong>
				<img alt="" src="images/show.png" ></strong></span></td>
			</tr>
		</table>
		</span></td>
	</tr>
</table>
<br>

';
	}

	function add_rep($name) {
		$tables = mysql_query( 'SHOW FIELDS FROM rep' );
		$num_tables = mysql_num_rows( $tables );

		if ($num_tables == 0) {
			mysql_query( 'CREATE TABLE rep (
  id int(12) unsigned NOT NULL auto_increment,
  comment text NOT NULL,
  user int(11) NOT NULL default \'0\',
  date varchar(10) NOT NULL default \'\',
  PRIMARY KEY  (id)
)ENGINE=MyISAM DEFAULT CHARSET=latin1' );
		}

		$q2 = 'insert into rep(user,comment,date)values(\'' . $_SESSION['iduser'] . ( '' . '\',\'' . $name . '\',\'' ) . time(  ) . '\')';
		mysql_query( $q2 );
	}

	function date_admin($data = '') {
		if (ereg( '/', $data )) {
			return $data;
		}

		$w = mysql_query( 'select * from  setting where id=\'2\'' );

		while ($row = mysql_fetch_row( $w )) {
			if ($data) {
				return date( ' h:i  d-m-Y', $data );
			}
		}

	}

	function editor($co = '') {
		$rowarray = mysql_query( 'select msgclose from  setting  where ba=\'settingnews\'   LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (file_exists( 'editor2.php' )) {
			include( 'editor2.php' );
			return $ddddd;
		}


		if ($rowarray['msgclose']) {
			return '' . '<div dir=rtl align=center><script language=\'JavaScript\' type=\'text/javascript\' src=\'tools.js\'>
</script> <textarea dir=ltr id=\'comment' . $co . '\' name=\'comment' . $co . '\' style=\'height: 170px; width: 500px;\'>
{edit_comment}</textarea></div>
<script language=\'javascript1.2\'>
  generate_wysiwyg(\'comment' . $co . '\');
</script>';
		}

		return '' . '<script type=\'text/javascript\' src=\'./images/tiny_mce/tiny_mce.js\'></script>
  <script type=\'text/javascript\' src=\'./images/tiny_mce/plugins/tinybrowser/tb_tinymce.js.php\'></script>
<script type=\'text/javascript\'> 
	tinyMCE.init({
		// General options
		mode : \'specific_textareas\',        
         editor_selector : \'articla\' , 	        
		theme : \'advanced\',
                file_browser_callback : \'tinyBrowser\',
		plugins : \'pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave\',
 
		// Theme options
		theme_advanced_buttons1 : \'save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect\',
		theme_advanced_buttons2 : \'cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor\',
		theme_advanced_buttons3 : \'tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen\',
		theme_advanced_buttons4 : \'insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft\',
		theme_advanced_toolbar_location : \'top\',
		theme_advanced_toolbar_align : \'left\',
		theme_advanced_statusbar_location : \'bottom\',
        	theme_advanced_resizing : true
 
	});
</script>

 
<textarea name=\'comment' . $co . '\' class=\'articla\' rows=\'15\' cols=\'80\' style=\'width: 80%\'> {edit_comment}</textarea>
';
	}

	function html2txt($document) {
		$search = array( '@<script[^>]*?>.*?</script>@si', '@<style[^>]*?>.*?</style>@siU', '@<[\/\!]*?[^<>]*?>@si', '@<![\s\S]*?--[ \t\n\r]*>@' );
		$text = preg_replace( $search, '', $document );
		return $text;
	}

	function list_categoriesssc($catid, $name = '', $cats = '', $catss = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `catid` = ' . $catid );

		while ($result = @mysql_fetch_array( $query )) {
			if (!$catss) {
				if ($result[5] != 0) {
					$cats = $result[0];
				}
			}

			$name = '' . '<a  href="edit.php?action=showcat' . $catss . '&cats=' . $cats . '&catid=' . $result['0'] . '">' . $result['1'] . '</a>' . $name;

			if ($result[2] == 1) {
				echo '
      ' . $name . '  ';
				continue;
			}

			list_categoriesssc( $result[2], ' � ' . $name, $cats, $catss );
		}

	}

	function list_catoptionadmincat($catid, $name = '', $catidv = '', $catidvd = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `parentcatid` = ' . $catid . ' ' );

		while ($result = @mysql_fetch_array( $query )) {
			if (( $result[5] == 0 || $result[5] == 4 )) {
				if ($result[0] == $catidv) {
					echo '' . '  <option value="' . $result['0'] . '"   selected>  ' . $name . ' ' . $result['1'] . '</option>';
					continue;
				}


				if ($result[0] != $catidvd) {
					echo '' . '  <option value="' . $result['0'] . '">  ' . $name . $result['1'] . '</option>';
					list_catoptionadmincat( $result[0], $name . $result[1] . '>', $catidv, $catidvd );
					continue;
				}

				continue;
			}
		}

	}

	function list_catoptionadmincatt($catid, $name = '', $catidv = '', $catidvd = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `parentcatid` = ' . $catid . '  and cat=5' );

		while ($result = @mysql_fetch_array( $query )) {
			if ($result[0] == $catidv) {
				echo '' . '  <option value="' . $result['0'] . '"   selected>  ' . $name . ' ' . $result['1'] . '</option>';
				continue;
			}


			if ($result[0] != $catidvd) {
				echo '' . '  <option value="' . $result['0'] . '">  ' . $name . $result['1'] . '</option>';
				list_catoptionadmincatt( $result[0], $name . $result[1] . '>', $catidv, $catidvd );
				continue;
			}
		}

	}

	function list_addplay($catid, $name, $sum = '') {
		$result = mysql_query( 'SHOW FIELDS FROM cat' );
		$teets = mysql_num_rows( $result );

		if ($teets == 18) {
			mysql_query( 'backtdER TABLE `cat` ADD `updata` INT( 15 ) NOT NULL  ' );
		}

		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `catid` = ' . $catid );

		while ($result = @mysql_fetch_array( $query )) {
			if ($name == '+') {
				$updata = ' ,updata=' . time(  );
			}


			if ($sum) {
				$upsum = $sum;
			} 
else {
				$upsum = 1;
			}

			mysql_query( 'update cat set allplay=allplay' . $name . ( '' . $upsum . '  ' . $updata . '  where catid=\'' . $result['0'] . '\'' ) );
			list_addplay( $result[2], $name, $sum );
		}

	}

	function list_addplay1($catid, $name, $sum = '') {
		$result = mysql_query( 'SHOW FIELDS FROM cat' );
		$teets = mysql_num_rows( $result );

		if ($teets == 18) {
			mysql_query( 'backtdER TABLE `cat` ADD `updata` INT( 15 ) NOT NULL  ' );
		}

		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `catid` = ' . $catid . '  and cat=\'5\'' );

		while ($result = @mysql_fetch_array( $query )) {
			if ($name == '+') {
				$updata = ' ,updata=' . time(  );
			}


			if ($sum) {
				$upsum = $sum;
			} 
else {
				$upsum = 1;
			}

			mysql_query( 'update cat set allplay=allplay' . $name . ( '' . $upsum . '  ' . $updata . '  where catid=\'' . $result['0'] . '\'' ) );
			list_addplay1( $result[2], $name, $sum );
		}

	}

	function list_addcat($catid, $name, $sum = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `catid` = ' . $catid );

		while ($result = @mysql_fetch_array( $query )) {
			if ($sum) {
				$upsum = $sum;
			} 
else {
				$upsum = 1;
			}

			mysql_query( 'update cat set allcat=allcat' . $name . ( '' . $upsum . ' where catid=\'' . $result['0'] . '\'' ) );
			list_addcat( $result[2], $name, $sum );
		}

	}

	function catoptionadmin($cat, $title = '') {
		echo '' . '	<tr><td  class=\'backtd\'   align=\'middle\'>
�����������  ���� ���� ��� ' . $title . '
</td><td class=\'backtd2\'    colspan=\'2\' align=\'right\'>';
		echo '' . '<select  name=\'' . $cat . '\'>';
		$a = mysql_query( 'select * from  cat where parentcatid=\'1\'' );

		while ($row = mysql_fetch_row( $a )) {
			if (( $row[5] == 3 || $row[5] == 4 )) {
				continue;
			}

			echo '' . ' <option value=\'' . $row['0'] . '\'>' . $row['1'] . '</option> ';
			$aa = mysql_query( '' . 'select * from  cat where parentcatid=\'' . $row['0'] . '\' and cat!=0 and cat!=4  and cat!=5' );

			while ($rowa = mysql_fetch_row( $aa )) {
				echo '' . '  <option value=\'' . $rowa['0'] . '\'>' . $row['1'] . '>>' . $rowa['1'] . '</option> ';
			}
		}

		echo '</select></td></tr>';
	}

	function list_catoptionadmina($catid, $name = '', $catidv = '', $catidvd = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `parentcatid` = ' . $catid . '  and cat=\'5\'' );

		while ($result = @mysql_fetch_array( $query )) {
			if ($result[0] == $catidv) {
				echo '' . '  <option value="' . $result['0'] . '"   selected>d  ' . $name . $result['1'] . '</option>';
			} 
else {
				echo '' . '  <option value="' . $result['0'] . '"> d ' . $name . $result['1'] . '</option>';
			}

			list_catoptionadmina( $result[0], $name . $result[1] . '>', $catidv );
		}

	}

	function list_catoptionadmin($catid, $name = '', $catidv = '', $catidvd = '') {
		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `parentcatid` = ' . $catid . ' ' );

		while ($result = @mysql_fetch_array( $query )) {
			if (!$catidvd) {
				if (( $result[5] == 0 || $result[5] == 4 )) {
					if ($result[0] == $catidv) {
						echo '' . '  <option value="' . $result['0'] . '"   selected>  ' . $name . $result['1'] . '</option>';
					} 
else {
						echo '' . '  <option value="' . $result['0'] . '">  ' . $name . $result['1'] . '</option>';
					}
				}

				list_catoptionadmin( $result[0], $name . $result[1] . '>', $catidv );
				continue;
			}
		}

	}

	function list_catoptionadmin1($catid, $name = '', $catidv = '', $cat = '') {
		if ($cat) {
			$dddd = 'cat=5';
		} 
else {
			$dddd = 'cat=0 or cat=4';
		}

		$query = @mysql_query( '' . 'SELECT * FROM `cat` WHERE `parentcatid` = ' . $catid . ' and (' . $dddd . ')' );

		while ($result = @mysql_fetch_array( $query )) {
			if ($result[0] == $catidv) {
				echo '' . '  <option value="' . $result['0'] . '"   selected>  ' . $name . $result['1'] . '</option>';
			} 
else {
				echo '' . '  <option value="' . $result['0'] . '">  ' . $name . $result['1'] . '</option>';
			}

			list_catoptionadmin1( $result[0], $name . $result[1] . '>', $catidv, $cat );
		}

	}

	function do_html_a1($title = '') {
		echo '<html dir=\'rtl\'>';
		echo '<HEAD>';
		echo '' . '<TITLE>' . $title . ' , ���� ������ </TITLE>';
		echo '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1256">';
		echo '</HEAD><LINK href="style.css" type=text/css rel=StyleSheet>    ';
		echo '<BODY  bottomMargin=0 leftMargin=0 rightMargin=0
topMargin=0   class=\'index\' marginwidth="0" marginheight="0">';
		echo '<s';
		echo 'cript language=\'JavaScript\'>
    function checkFiles(name){
if(window.confirm(\'�� ����� �� ��� ������ �\'+name)){return ture;	}else{return false;}}
    function checkFiless(name){
if(window.confirm(\'�� ����� �� ��� \'+name)){return ture;	}else{return false;}}
   </script>';
		echo '<s';
		echo 'tyle type="text/css">
';
		$a = mysql_query( 'select * from  setting where id=\'' . $_SESSION['styleadmin'] . '\'' );

		while ($row = mysql_fetch_row( $a )) {
			$css = $row[5];
			echo stripslashes( $css );
		}


		if (!$css) {
			$a = mysql_query( 'select * from  setting where  close=\'1\' and sl=\'styleadmin\' ' );

			while ($row = mysql_fetch_row( $a )) {
				$css = $row[5];
				echo stripslashes( $css );
			}
		}

		echo '</style>
';
	}

	function do_html_a2() {
		echo '<TABLE dir=\'ltr\' WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=0>';
		echo '<TR>';
		echo '<TD valign="top"><center>';
		echo '      ';
		echo '<s';
		echo 'cript language="JavaScript">
function checkAll(form){
  for (var i = 0; i < form.elements.length; i++){
    eval("form.elements[" + i + "].checked = form.elements[0].checked");
  }

}

function funHSLinks(varO1, varO2){
document.getElementById(varO1).style.display="none";
document.getElementById(varO2).style.display="block";
}
</script> 
                <TABLE dir=rtl id=table2 height=4 ';
		echo 'width=95% border=0>
                            <TR>
                              <TD vAlign=top width=100% height=1 rowSpan=2>
                                <table width="100%"  cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="100%"  class=\'page\'  height="30" align="center">

';
	}

	function do_html_a3() {
	}

	function do_html_a4() {
		$usrl = getenv( 'SERVER_NAME' );
		$usrl = str_replace( 'www.', '', $usrl );
		$timee = 86400;
		$usrld = explode( '.', $usrl );
		$filelise = '../lisen.date';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$entries = explode( ',', $contents );
		$entriess = explode( '=', $entries[1] );

		if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
			echo ' <br><br><br><center><a  target=\'_blank\' href="http://www.xdecoderx.com/vb/"><img src="images/xdecoderx.png" width="150" height="150" /></a>';
		}

		echo '</td></tr></table></TD></TR></TABLE>   </TD>';
	}

	function admin_error($iduser, $cat_id) {
		$ws = mysql_query( '' . 'select * from user where id=\'' . $iduser . '\'' );

		while ($row = mysql_fetch_row( $ws )) {
			$username = $row[1];
			$group = $row[5];
			$words = explode( '||', $row[4] );
			$i = 0;

			while ($i < count( $words )) {
				$newtext = $words[$i];
				$p_id[$newtext] = $newtext;
				++$i;
			}
		}


		if ($p_id[$cat_id] != $cat_id) {
			do_html_a1(  );
			do_html_a2(  );
			echo '����� ���';
			do_html_a3(  );
			echo '����� ��� ����� �� �������� ����  ';
			do_html_a4(  );
			exit(  );
		}

	}

	function pages($page, $pages, $urlpage) {
		if (1 < $page) {
			$prev = $page - 1;
			$ec = '' . ' <font class=\'fonttable2\'>[ </font><a href=' . $urlpage . ( '' . 'page=' . $prev . '>������</a> <font class=\'fonttable2\'>]  </font>' );
		}


		if (3 < $page) {
			echo '' . '<font class=\'fonttable2\'>[ </font><a  href=' . $urlpage . 'page=1>1</a> <font class=\'fonttable2\'> ]    </font> ';

			if ($page <= 7) {
				echo '.....    ';
			}
		}


		if (7 < $page) {
			echo '' . '<font class=\'fonttable2\'>[ </font><a  href=' . $urlpage . 'page=2>2</a> <font class=\'fonttable2\'> ]   ..... </font>';
		}


		if ($page == $pages - 1) {
			$j = $page - 3;
		} 
else {
			if ($page == $pages) {
				$j = $page - 4;
			} 
else {
				if (2 < $page) {
					$j = $page - 2;
				}
			}
		}

		$i = 1;

		while ($i < 7) {
			if ($page == $j) {
				if (1 < $pages) {
					echo '' . '   <font class=\'fonttable2\'>[ <b><big>' . $j . '</big></b> ]   </font>';
				}
			} 
else {
				if (( ( 0 <= $j && $j ) && $j <= $pages )) {
					echo '' . '<font class=\'fonttable2\'> [  </font><a  href=' . $urlpage . ( '' . 'page=' . $j . '>' . $j . ' </a> <font class=\'fonttable2\'>]   </font>' );
				}
			}

			$j = $j + 1;
			++$i;
		}


		if ($page + 4 < $pages) {
			if (6 < $pages) {
				$pagess = $pages - 1;
				echo '' . '<font class=\'fonttable2\'>..... [  </font><a  href=' . $urlpage . ( '' . 'page=' . $pagess . '>' . $pagess . ' </a> <font class=\'fonttable2\'> ]   </font>' );
			}
		}


		if ($page + 3 < $pages) {
			echo '' . ' <font class=\'fonttable2\'>[ </font><a  href=' . $urlpage . ( '' . 'page=' . $pages . '>' . $pages . ' </a> <font class=\'fonttable2\'> ]  </font> ' );
		}


		if ($page < $pages) {
			$next = $page + 1;
			echo '' . ' <font class=\'fonttable2\'>[ </font><a  href=' . $urlpage . ( '' . 'page=' . $next . '>������</a> <font class=\'fonttable2\'> ]  </font>' );
		}

	}

	function page_error($group) {
		if ($group != '1') {
			do_html_a2(  );
			echo '���� ���';
			do_html_a3(  );
			echo '���� ��� ����� �� �������� ����  ';
			do_html_a4(  );
			exit(  );
		}

	}

	$usrl = getenv( 'SERVER_NAME' );
	$usrl = str_replace( 'www.', '', $usrl );
	$timee = 86400;
	$usrld = explode( '.', $usrl );
	$ip = getenv( 'REMOTE_ADDR' );
	$filelise = './lisen.date';

	if (!file_exists( 'config.php' )) {
		$filelise = '.' . $filelise;
	}


	if (!file_exists( '' . $filelise )) {
		
	} 
else {
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$entries = explode( ',', $contents );
		$entriess = explode( '=', $entries[1] );

		if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '19850827' . 'a123987' ) ) ) ) ), $entriess )) {
			if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
				if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . 'e19850827' . 'a123987' ) ) ) ) ), $entriess )) {
					if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . 'e198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
						$url = 'http://mktba.org/select.php?action=error&dominold=' . $entries[0] . '&dominnew=' . $usrl . '&ip=' . $ip;
						echo url_curl( $url, 'error' );
						exit( '<br><div align=center><big>������� ��� ���� ���� ���� �������<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
					}
				}
			}
		}
	}


	if (is_dir( '../install' )) {
		exit( '<br><div align=center><big>��� ��� ���� install<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
	}

?>