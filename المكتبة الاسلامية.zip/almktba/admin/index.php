﻿<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/         

	include( '../config.php' );
	require( 'session.php' );
	include( 'funcadmin.php' );
	$isxdecoderxadmin=1;
	echo '<html dir=\'rtl\' class=\'index\'>';
	echo '<HEAD>';
	echo '<LINK href="style.css" type=text/css rel=StyleSheet>    ';
	mysql_query( 'DELETE FROM comment WHERE msg=\'rep\' and  date < \'' . ( time(  ) - 60 * 60 * 24 * 10 ) . '\'' );

	if ($_POST['styleadmin']) {
		$_SESSION['styleadmin'] = $_POST['styleadmin'];
	} 
else {
		if (!$_SESSION['styleadmin']) {
			$a = mysql_query( 'select * from  setting where sl=\'styleadmin\' and close=1 order by id desc limit 1' );
			$teet = mysql_num_rows( $a );

			if ($teet == 0) {
				mysql_query( 'insert setting set ba=\'???? ,sl=\'styleadmin\',close=1,msgclose=\'body.index{
background-color: #F1EED4;/*    ? ????/
}

.backtd {/*    ? ?????????*/
FONT-SIZE: 9pt; 
COLOR: #A70303;
 FONT-FAMILY: Tahoma;
 background-color: #E2DCAF;
}
.tabletd {/*    ? ???/
 background-color: #824E05;
  COLOR: #FFFFFF; 
FONT-SIZE: 9pt;
 FONT-FAMILY: Tahoma;
}

.uptable{/*    ??????
 background-color: #E0B17A;
  COLOR: #000000;
FONT-SIZE: 9pt;
  FONT-FAMILY: Tahoma;
}
TD {
       FONT-SIZE: 9pt; COLOR: #000000; FONT-FAMILY: Tahoma
}
A {
        FONT-SIZE: 10pt; COLOR: #A70303; FONT-FAMILY: Tahoma; TEXT-DECORATION: none
}
A:hover {
        FONT-SIZE: 10pt; COLOR: #7A4F25; FONT-FAMILY: Tahoma
}

BODY {
      MARGIN: 5px; 
}


P {
        FONT-SIZE: 9pt; COLOR: #7A4F25; FONT-FAMILY: Tahoma
}

/*    ??????/
.arrowlistmenu .menuheader1{ /*    ????? ????/
color: white;/*  ? ??*/
background: #D9220E ;/*    ? ????/

}
.tablestting {/*     ??? ????/
FONT-SIZE: 9pt;
 COLOR: #FFFFFF; /*  ? ??*/
FONT-FAMILY: Tahoma;
background-color: #A32A1D;/*    ? ????/
 font-weight: bold;
}

.arrowlistmenu .menuheader{ /*   ????? ????/
font:  12px Tahoma;
color: white;
background: #908427 ;/*  ? ????/
margin: 6px; 
text-transform: uppercase;
padding: 4px 0 4px 10px; 
cursor: hand;
cursor: pointer;
}
\'  ' );
				$ad = mysql_query( 'select * from  setting where sl=\'styleadmin\' and close=1 order by id desc limit 1' );

				while ($rowd = mysql_fetch_row( $ad )) {
					$_SESSION['styleadmin'] = $rowd[2];
				}
			}


			while ($row = mysql_fetch_row( $a )) {
				$_SESSION['styleadmin'] = $row[2];
			}
		}
	}

	echo '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1256">';
	$w = mysql_query( 'select * from  setting where id=\'1\'' );

	while ($row = mysql_fetch_row( $w )) {
		echo '' . '<TITLE> لوحة تحكم ' . $row['3'] . '</TITLE></HEAD>';
	}

	echo '<frameset rows="27,*">
        <frame   frameborder="0" SCROLLING=\'no\' target="ddddd" name="ddddd" scrolling="no" noresize  src="uppage.php">
        <frameset  cols="*,207">   ';
	echo '<frame   frameborder="0"  target="frame3"    width=\'100%\' height=\'100%\' name="frame3"  noresize  src="rightpage.php">';
	echo '<frame  target="frame2" frameborder="0"      width=\'150\' height=\'100%\' name="frame2"  noresize src="leftpage.php">
        </frameset>
</frameset>
';
	exit(  );
?>