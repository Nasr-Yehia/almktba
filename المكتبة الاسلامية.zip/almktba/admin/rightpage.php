<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/        

	include( '../config.php' );
	require( 'session.php' );
	include( 'funcadmin.php' );
	do_html_a1( '������ ��������' );
	do_html_a2(  );
	$action = $_GET['action'];
	$tables = mysql_query( 'SHOW FIELDS FROM linkat' );
	$num_tables = mysql_num_rows( $tables );

	if ($num_tables == 0) {
		mysql_query( '  ALTER TABLE `user` CHANGE `newpass` `newpass` VARCHAR( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL ' );
		mysql_query( 'CREATE TABLE `linkat` (
  `id` int(11) NOT NULL auto_increment,
  `catsmktba` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `visible` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `counter` int(11) NOT NULL,
  `mediatype` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ' );
	} 
else {
		if ($num_tables == 6) {
			mysql_query( '	ALTER TABLE `linkat` ADD `image` VARCHAR( 25 ) NOT NULL ,
ADD `counter` INT NOT NULL ,
ADD `mediatype` VARCHAR( 250 ) NOT NULL ' );
		}
	}

	$tables = mysql_query( 'SHOW FIELDS FROM styles' );
	$num_tables = mysql_num_rows( $tables );

	if ($num_tables == 0) {
		e_error( '������ ������ ���� ����� ���������� ���� <a  href=\'?convert=ok\'  > ���� ���</a>' );
	}

	$ws = mysql_query( 'select * from user where id=\'1\'' );

	while ($row = mysql_fetch_row( $ws )) {
		$comm = $row[4];
	}


	if ($action == edit) {
		$ws = mysql_query( 'select * from user where id=\'1\'' );

		while ($row = mysql_fetch_row( $ws )) {
			$comm = $row[4];
		}

		echo '  <form method="POST" action="?">
<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
����� �� ������ �����	
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1"';
		echo ' cellSpacing="0" cellPadding="3" width="95%" align="center" style="direction: rtl">

	
<tr align="middle">
<td width="50%"  style="width: 0; height: 100%"   class="backtd2">
 
  <textarea name=\'comment\' rows=11 cols=65>';
		echo $comm;
		echo '</textarea>
                                    <br>���� ������� ��� ���� �� ������
	</tr> 
	
	<tr align="middle">
<td width="50%"  style="width: 0; height: 100%"   class="backtd2">
	<form method="POST" action="?action=edit"><input type="submit" value="�����"  class=\'button\'  > 

	</tr> 



	

        </table> </form>

';
	}


	if (!$action) {
		$url = $_SERVER['SERVER_NAME'];
		$ws = mysql_query( 'select * from user where id=\'1\'' );

		while ($row = mysql_fetch_row( $ws )) {
			$comm = $row[4];
		}


		if ($_SESSION['group'] == 1) {
			$wmsg = mysql_query( 'select * from comment where msg=\'3\' and  counter=\'1\' ' );
			$catmsg = mysql_num_rows( $wmsg );
			$wcom = mysql_query( 'select * from comment where msg=\'1\' and   ( counter=1 or counter=3 ) ' );
			$catcom = mysql_num_rows( $wcom );
			$wbook = mysql_query( 'select * from comment where msg=\'2\' and  counter=\'1\' ' );
			$catbook = mysql_num_rows( $wbook );
			$www = mysql_query( 'select * from  play where ctid2=\'10000000\' ORDER BY `id` DESC ' );
			$teet = mysql_num_rows( $www );
			$wwsw = mysql_query( 'select * from  comment where msg=\'erro\'  ORDER BY `id` DESC ' );
			$teets = mysql_num_rows( $wwsw );
			$www = mysql_query( 'select * from  play where ctid2=\'10000001\' ORDER BY `id` DESC ' );
			$teetd = mysql_num_rows( $www );
			$url = $_SERVER['SERVER_NAME'];
			$comment = $_POST[comment];

			if ($comment) {
				mysql_query( '' . 'update user set comm=\'' . $comment . '\' where id=\'1\'' );
			}

			echo '<table style="width: 98%">
	<tr>
		<td>

<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
���� ���� ������	
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border=';
			echo '"1" cellSpacing="0" cellPadding="3" width="95%" align="center" style="direction: rtl">

	
<tr align="middle">
<td width="40%"      >
 <a href="contect.php">����� ��������  
</a></td>
<td width="10%"      class="backtd">
 <a href="contect.php"><b>';
			echo $catmsg;
			echo '</b>
</a></td>
<td width="40%"    >
<a href="comment.php">�������������������  
</a></td>
<td width="10%"    class="backtd">
<a href="comment.php"><b>';
			echo $catcom;
			echo '</b>
</a></td>

	</tr> 
	
	<tr align="middle">
<td width="40%"      class="backtd2">
 <a href="guestbook.php" >������ ��������� 
</a></td>
<td width="10%"      class="backtd">
 <a href="guestbook.php" ><b>';
			echo $catbook;
			echo '</b>
</a></td>
<td width="40%"    class="backtd2">
 <a href="mosahm.php" >������� ������  
</a></td>
<td width="10%"    class="backtd">
 <a href="mosahm.php" ><b>';
			echo $teet;
			echo '</b>
</a></td>

	</tr> 
	
	
	<tr align="middle">
<td width="40%"      class="backtd2">
 <a href="linkerro.php" >����� ������
</a></td>
<td width="10%"      class="backtd">
 <a href="linkerro.php" ><b>';
			echo $teets;
			echo '</b>
</a></td>
<td width="40%"    class="backtd2">
<a href="deluser.php" > ������� �������� 
</a></td>
<td width="10%"    class="backtd">
<a href="deluser.php" ><b>';
			echo $teetd;
			echo '</b>
</a></td>

	</tr> 
	
	
	

	

        </table></td>
        
';
			$usrl = getenv( 'SERVER_NAME' );
			$usrl = str_replace( 'www.', '', $usrl );
			$timee = 86400;
			$usrld = explode( '.', $usrl );
			$filelise = '../lisen.date';
			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );
			$entries = explode( ',', $contents );
			$entriess = explode( '=', $entries[1] );

			if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
				echo '    	<td>
<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
����� ������� ���������		
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cell';
				echo 'Padding="3" width="95%" align="center" style="direction: rtl">


<tr align="middle">
<td width="30%"   class="backtd2">
��� ��������</td>
<td width="10%"    class="backtd" align="right">
<b>6.4</b></td>
<td width="35%"   class="backtd2">
����� �������</td>
<td  width="25%"   class="backtd" align="right">
<b>10-10-2011</b></td>

	</tr> 
	
	
<tr align="middle">
<td width="25%"  colspan="2"    class';
				echo '="backtd2">
 <a href="http://www.mktba.org/ticket.php" target="_blank">����� ����� �����
</a></td>
<td width="25%"   colspan="2"  class="backtd2">
<a href="http://www.mktba.org" target="_blank">���� �������
</a></td>

	</tr> 
	
	<tr align="middle">
<td width="25%"  colspan="2"    class="backtd2">
 <a href="http://www.mktba.org/help" target="_blank">xx
</a></td>
<td width="25%"   colspan';
				echo '="2"  class="backtd2">
<a href="http://www.mktba.org/na" target="_blank">����� �������
</a></td>

	</tr> 
	

        </table> </td>
        ';
			}

			echo '      
	
	</tr>
</table>












';

			if (file_exists( 'rightpage2.php' )) {
				include( 'rightpage2.php' );
			}


			if (file_exists( 'backuser.php' )) {
				e_error( '���� ��� ��� backuser.php ������ ������' );
			}
		}

		echo '


<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
����� �� ������ �����	
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding';
		echo '="3" width="95%" align="center" style="direction: rtl">

	
<tr align="middle">
<td width="50%"  style="width: 0; height: 100%"   class="backtd2">
';
		echo $comm;
		echo ' 

	</tr> 
	';

		if ($_SESSION['group'] == 1) {
			echo '	<tr align="middle">
<td width="50%"  style="width: 0; height: 100%"   class="backtd2">
	<form method="POST" action="?action=edit"><input type="submit" value="�����"  class=\'button\'  > 

	</tr> 
';
		}

		echo '

	

        </table> </form>
<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
������ ����� ��������
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" c';
		echo 'ellSpacing="0" cellPadding="3" width="95%" align="center" style="direction: rtl">



	

 

';
		echo '    ';
		echo '    <tr  >';
		echo '    <td width="65%" class="uptable" >����� �������</td>';
		echo '    <td width="20%"  class="uptable" >��� ��</td>';
		echo '    <td width="15%"   class="uptable" >�������</td>';
		echo '  </tr> ';
		$sql1 = mysql_query( '' . 'select * from comment   WHERE msg=\'mshrf\' ' . $ddd . ' order by id  desc limit 5' );

		while ($row = mysql_fetch_row( $sql1 )) {
			$row[2] = htmlspecialchars( $row[2] );

			if ($row[6] == '') {
				$row[6] = '�� ��� �����';
			}


			if ($r3232 == 1) {
				echo '<tr    class=\'backtd\'>';
				$r3232 = 0;
			} 
else {
				echo '<tr  >';
				$r3232 = 1;
			}

			echo '' . '  <td  ><a href="mshrf.php?action=readmsg&&id=' . $row['0'] . '">' . $row['6'] . '</a> ' . $neww . '</td>';
			$sqlss = mysql_query( '' . 'select * from comment where idplay=\'' . $row['0'] . '\' and msg=\'rdmshrf\' order by id desc limit 1' );
			$catcom = mysql_num_rows( $sqlss );

			while ($rows = mysql_fetch_row( $sqlss )) {
				$naemcat = $rows[2];
			}


			if (!$naemcat) {
				$naemcat = '������ ��';
			}

			echo '' . '    <td   >' . $naemcat . '</td>';
			echo '    <td  ><small>' . date_admin( $row[4] ) . '</small></td> ';
			echo '</tr>';
		}

		echo ' <td   colspan="3"    align="left"><a href="mshrf.php"><b>����� ��������</b></a> </td></tr></table>     </td>
	
	</tr>
</table>';

		if ($_SESSION['group'] == 1) {
			$ws = mysql_query( 'select * from cat where catid=\'1\'' );

			while ($row = mysql_fetch_row( $ws )) {
				$comm = $row[18];
			}

			echo '


<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cellPadding="3" width="95%" align="center">
	<tr>
		<td class="tabletd" width="100%" align="center"  valign="middle">
������� ��������� � ���������	
		</td>
		</tr>
</table>

<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="0" cel';
			echo 'lPadding="3" width="95%" align="center" style="direction: rtl">

	
<tr align="middle">
<td width="50%"  style="width: 0; height: 100%"   class="backtd2">
';
	echo "<center><img src='images/laa.jpg' /></center>";
			echo '<s';
			echo 'cript language="JavaScript" src="http://www.mktba.org/updata6.php?url=';
			echo $url;
			echo '&V=6.4&update=';
			echo $comm;
			echo '"></script> 
</td>
	</tr> 
</table><table width=\'100%\'><tr><td align=\'center\'>
        <img border=\'0\' src=\'images/low.jpg\' width=\'20\' height=\'20\'>
        ';
			echo '<s';
			echo 'pan lang=\'ar-sa\'>�����</span>&nbsp;&nbsp;&nbsp;
        <img border=\'0\' src=\'images/medium.jpg\' width=\'17\' height=\'19\'>
        ';
			echo '<s';
			echo 'pan lang=\'ar-sa\'>����� �������</span>&nbsp;&nbsp;
        <img border=\'0\' src=\'images/high.jpg\' width=\'20\' height=\'18\'>
';
			echo '<s';
			echo 'pan lang=\'ar-sa\'>&nbsp;����� �����
</span></td></tr></table>

';
		}
	}

	do_html_a4(  );
	ob_end_flush(  );
?>