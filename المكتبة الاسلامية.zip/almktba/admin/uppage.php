﻿<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/          

	include( '../config.php' );
	require( 'session.php' );
	echo '<s';
	echo 'tyle type="text/css">
';
	$a = mysql_query( 'select * from  setting where id=\'' . $_SESSION['styleadmin'] . '\'' );

	while ($row = mysql_fetch_row( $a )) {
		$css = $row[5];
		echo $css;
	}


	if (!$css) {
		$a = mysql_query( 'select * from  setting where  close=\'1\' and sl=\'styleadmin\' ' );

		while ($row = mysql_fetch_row( $a )) {
			$css = $row[5];
			echo stripslashes( $css );
		}
	}

	echo '?>
</style>
';
	echo '</HEAD><LINK href="style.css" type=text/css rel=StyleSheet>    ';
	echo '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1256">';
	echo '<BODY bottomMargin=0 leftMargin=0 rightMargin=0
topMargin=0  marginwidth="0" marginheight="0" class=\'index\'>';
	echo ' <table border="0" DIR=rtl width="100%" id="table1" cellspacing="0" cellpadding="0">
        <tr>
                <td  width="80%" dir=rtl> اهلا بك ,<B> ';
	echo $_SESSION['admin'];
	echo '</B>      &nbsp; ||    &nbsp; <A     target=\'_parent\' href="index.php">الرئيسية</A>  &nbsp;   ||    &nbsp;   <A
                 href="mshrf.php"
target=frame3>منتدى المشرفين</A>  &nbsp;||    &nbsp;   <A
                 href="../index.php"
target=_blank>واجهة الموقع الرئيسيةֹ</A>  &nbsp;  ||   &nbsp;   <big><B><A style="TEXT-DECORATION: none"
                target=\'_parent\'     href="logout.php">تسجيل الخروج</';
	echo 'A>    </B></big></B>    </td><td width="15%"><div align="right">  ';
	echo '<s';
	echo 'cript language="JavaScript" src="http://www.schoolgold.net/updata2.php?V=6.2"></script> </div></td>
                <td width="35"><div align="left"></div></td>
        </tr>
</table>';
?>