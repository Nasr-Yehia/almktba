<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/          

	@session_start(  );
	include( '../config.php' );

	if (( $_SESSION['admin'] && ( $_SESSION['group'] == 1 || $_SESSION['group'] == 2 ) )) {
		require( 'loged.php' );
		exit(  );
	}


	if (isset( $_POST['user_pw'] )) {
		$tables = mysql_query( 'SHOW FIELDS FROM cat' );
		$num_tables = mysql_num_rows( $tables );

		if ($num_tables == 0) {
		}

		$userun = $_POST['user_un'];
		$userpw = md5( md5( $_POST['user_pw'] ) );
		$ws = mysql_query( '' . 'select * from user where name=\'' . $userun . '\' and pass=\'' . $userpw . '\' and(gruop=\'1\'  or gruop=\'2\' )' );

		while ($row = mysql_fetch_row( $ws )) {
			$data = time(  );
			mysql_query( '' . 'update user set reglog=\'' . $data . '\'  where name=\'' . $userun . '\'' );
			$_SESSION['user2'] = $_POST['user_pw'];
			$_SESSION['user1'] = $userun;
			$iduser = $row[0];
			$username = $row[1];
			$password = $row[2];
			$group = $row[5];
		}


		if (( $userpw == $password && $userun == $username )) {
			$_SESSION['admin'] = $userun;
			$_SESSION['group'] = $group;
			$_SESSION['iduser'] = $iduser;
			require( 'loged.php' );
			exit(  );
		}
	}

	echo '<LINK href="style.css" type=text/css rel=StyleSheet>    ';
	$action = $_GET['action'];

	if (!$action) {
		include( 'funcadmin.php' );
		$ad = mysql_query( 'select * from  setting where sl=\'styleadmin\' and close=1 order by id desc limit 1' );

		while ($rowd = mysql_fetch_row( $ad )) {
			$_SESSION['styleadmin'] = $rowd[2];
		}

		do_html_a1( '����� ������' );
		do_html_a2(  );
		echo '


  <!-- start form -->







<br><br><br><br>  <form method="post" action="login.php">

<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="3" cellPadding="3" width="50%" align="center">

	<tr>

		<td class="tabletd" width="100%" align="center"  valign="middle">

����� ������	

		</td>

		</tr>

</table>



<ta';
		echo 'ble style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="3" cellPadding="3" width="50%" align="center" style="direction: rtl">

       ';

		if ($_POST) {
			echo '
		<tr align="middle">

<td    colspan="3"    align="center"  class="backtd2">

  <font color="#FF0000">  #  ����� �� ������ ������</td></tr>

	';
		}

		echo '
<tr align="middle">

<td      class="backtd2" rowspan="2">

<img src="images/login.gif" style="width: 64px; height: 59px"></td>

<td      class="backtd2" style="width: 53%">

��� �������� 

</td>

<td    class="backtd2">

 <input name="user_un" id="username" size="30" /></td>

	

	<tr align="middle">

<td      class="backtd2" style="width: 53%">

��������� ����������

</td>

<td    ';
		echo 'class="backtd2">

  <input type="password" name="user_pw" id="password" size="30"/></td>

	

	

	<tr align="middle">

<td    colspan="3"     class="backtd2">

	<input type="submit" value="����� ����"  class=\'button\'  style="height: 21px" /></td>

	

	



	<tr align="middle">

<td    colspan="3"    align="right"  class="backtd2">

<img src="images/arrowbullet.png" style="width: 12px;';
		echo ' height: 12px">     <a href=\'login.php?action=forgot\'>���� ��� ��� ���� ���� ����</a></td>

	

	

	



	



        </table>











  <!-- end form -->

<br><br>



&nbsp;</p>

</center>



</body>



</html>

';
	}


	if ($action == forgot) {
		include( 'funcadmin.php' );
		$ad = mysql_query( 'select * from  setting where sl=\'styleadmin\' and close=1 order by id desc limit 1' );

		while ($rowd = mysql_fetch_row( $ad )) {
			$_SESSION['styleadmin'] = $rowd[2];
		}

		do_html_a1( '����� ������' );
		do_html_a2(  );
		$email = addslashes( $_POST['email'] );
		$w = mysql_query( '' . 'select * from  user where  email=\'' . $email . '\'' );

		while ($row = mysql_fetch_row( $w )) {
			$webmaster_email = $row[3];
			$username = $row[1];
			$password = $row[2];
		}

		echo '


<br><br><br><br>  <form method="post" action="login.php?action=forgot">

<table style="BORDER-BOTTOM-WIDTH: 0px" style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="3" cellPadding="3" width="50%" align="center">

	<tr>

		<td class="tabletd" width="100%" align="center"  valign="middle">

������� ���� ������

		</td>

		</tr>

</table>



';

		if (( !$email || !$webmaster_email )) {
			echo '


  <!-- start form -->









<table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="3" cellPadding="3" width="50%" align="center" style="direction: rtl">

       ';

			if ($_POST) {
				if (!$email) {
					echo '
		<tr align="middle">

<td    colspan="3"    align="center"  class="backtd2">

  <font color="#FF0000">  #  ���� �������</td></tr>

	';
				} 
else {
					if (!$webmaster_email) {
						echo '
		<tr align="middle">

<td    colspan="3"    align="center"  class="backtd2">

  <font color="#FF0000">  #  ���� �� ������� ��� �����</td></tr>

	';
					}
				}
			}

			echo '
<tr align="middle">

<td      class="backtd2" rowspan="2">

<img src="images/login.gif" style="width: 64px; height: 59px"></td>

<td      class="backtd2" style="width: 53%">

���� �������

</td>

<td    class="backtd2">

 <input name="email"  size="30" /></td>

	

	

	<tr align="middle">

<td    colspan="3"     class="backtd2">

	<input type="submit" value="�������"  class=\'button\'  ';
			echo 'style="height: 21px" /></td>

	

	





	

	

	



	



        </table>











  <!-- end form -->

<br><br>



&nbsp;</p>

</center>



</body>



</html>

';
		} 
else {
			function random_password($chars = 8) {
				global $letters;

				$letters = 'abcefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
				$letters = substr( str_shuffle( $letters ), 0, $chars );
			}

			random_password(  );
			$pass = md5( md5( $letters ) );
			mysql_query( '' . 'update user set newpass=\'' . $pass . '\' where email=\'' . $email . '\'' );
			$subject = '������� ������ ����� ������
';
			$msg = ( '' . $Lag['userinfo'] . '	' );
			$msg .= '' . $Lag['username'] . ' :	' . $username;
			$msg .= '' . $Lag['password'] . ' :	' . $letters;
			include( '../class/SendM.php' );
			send_mail1( $subject, $msg, $email );
			echo '
   <table style="border-collapse: collapse" bordercolor="#C0C0C0"  border="1" cellSpacing="3" cellPadding="3" width="50%" align="center" style="direction: rtl">

   

   	<tr align="middle">

<td    colspan="3"     class="backtd2">

';
			echo $webmaster_email;
			echo '&nbsp;�� ����� ��� ������� </td>

	

	

	    </tr>



    </table>

';
		}
	}

	exit(  );
?>