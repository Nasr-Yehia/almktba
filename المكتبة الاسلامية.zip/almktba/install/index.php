﻿<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/        

	include( '../config.php' );
	echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="rtl" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>تنصيب المكتبه - xdecoderx</title>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1256" />
	<link rel="stylesheet" href="setup.css" type="text/css" />
</head>
<bo';
	echo 'dy>
<table cellpadding="3" cellspacing="1" width="100%" class="t_style_b" border="0" align="center">
<tr valign="top" align="center">
	<td class="header_logo_side" colspan="2"><img align="right" alt="PowerBB" border="0" src="logo.gif" /></td>
</tr>
<tr valign="top" align="center">
	<td class="main1" colspan="2">اهلا وسهلا بكم في تنصيب المكتبه - xdecoderx</td>
</tr>
</table><br />
 ';
	

	

	if (( !$_GET['page'] && !$_GET['upgrud'] )) {
		$result = mysql_query( 'SHOW FIELDS FROM comment' );
		$tables = @mysql_query( 'SHOW TABLE STATUS' );
		$num_tables = mysql_num_rows( $tables );

		if (9 < $num_tables) {
			echo '<form action="?page=1&reinstall=ok"  name="myform" method="post">';
			echo '<table cellpadding="3" cellspacing="1" width="60%" class="t_style_b" border="1" align="center">
<thead>
<tr>
	<th class="main1" align="center" colspan="2">الخطوه الاولى</th>
</tr>
</thead>
<tr valign="top">
		<td align="right" class="row1">
<b>هام جدا: هذه النسخه منزوعة الكود , النازع <a href="http://www.xdecoderx.com/vb" target="_blank">xdecoderx</a> لا يتحمل اية مسؤولية , مع العلم ان النسخة منزوعة بدون اية مشاكل</td>
</tr>
</table><br />
<div align="center"><tr>
	<td class="';
			echo 'submit-buttons" colspan="2" align="center">
	<input class="submit" type="submit" value="التالي" name="submit" accesskey="s" /></td>
</tr>
</table><br />
</form>
 
';
		} 
else {
			echo '<form action="?page=1"  name="myform" method="post">';
			echo '<table cellpadding="3" cellspacing="1" width="60%" class="t_style_b" border="1" align="center">
<thead>
<tr>
	<th class="main1" align="center" colspan="2">الخطوه التاليه</th>
</tr>
</thead>
<tr valign="top">
		<td align="right" class="row1">
1-?????? ???????????  ?? ??? ??????? ??? ????? ? ? ? ??? ???? ?????????? ??????  .<b';
			echo 'r>
2-??? ????????? ?????????? ??????.<br>
3-???????? ? ??? ??????? ??? ?????? ????br>
4-???????? ??? ????????? ?????????????? ?? .
<br>5-????????? ?????????????????.
<br>6-??? ? ?????????? ??? ?? ?? ? ????';
			echo '?? ?? ?? ??????? .
<br>7-??????????????????????? ??????`? ????? ?? ?? .<br>8-?????? ???? ?????????? ?????? ????? ??.<br>
<br>??????? ???     ???? ??? ???? ??? ????????????? ????????? ??????.
</td>
</tr>
</table><br />
<div ';
			echo 'align="center"><tr>
	<td class="submit-buttons" colspan="2" align="center">
	<input class="submit" type="submit" value="   ?? ????  " name="submit" accesskey="s" /></td>
</tr>
</table><br />
</form>
 
';
		}
	}


	if ($_GET['page'] == 1) {
		if ($_GET['reinstall']) {
			mysql_query( 'DROP TABLE `ads` ,`block` ,`cat` ,`comment` ,`linkat` ,`online` ,`play` ,`rep` ,`setting` ,`user`,styles ;' );
		}

		$filelise = 'setup.sql';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( '#-n3esa-', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		echo '
	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التالية</span></th>
</tr>
</table>
<form action="?page=2"  name="myform" method="post">
<table cellpadding="3" cellspacing="1" width="60%" class="t_style_b" border="1" align="center">
<thead>
<tr>
	<th class="main1" align="center" colspan="2">الرجاء كتابة معلومات موقعك</th>
</tr>
</thead>

';
		echo '<s';
		echo 'cript language="JavaScript">

function funHSLinksd(varO1, varO2){
if(varO2==1)
{
document.getElementById(varO1).style.display="none";
}else
{
document.getElementById(varO1).style.display="block";
}
}
</SCRIPT>
   <tr>
    <td width=\'25%\'>اسم الموقع</td>
    <td width=\'50%\'><input name=\'sitname\' type=\'text\' value=\'\' size=\'35\'></td>
  </tr>
    <tr>
    <td width=\'25%\'>بريد الموقع</td';
		echo' >
    <td width=\'50%\'><input name=\'email\' type=\'text\' value=\'\' size=\'35\'></td>
  </tr>
    <tr>
    <td width=\'25%\'>عنوان الموقع - امتداد رابط السكربت</td>
    <td width=\'50%\'><input name=\'url\' type=\'text\' value=\'\' size=\'35\'><br> http://mktba.org/</td>
  </tr>  <tr>
    <td width=\'25%\'>اختر المحتوى</td>
    <td width=\'50%\'><input type="radio"  checked onclick="javascript:funHSLinksd(9100119111,2)"  value="3" name="showcat" >';
		echo 'محتوى اسلامي<input type="radio"  value="1" name="showcat"   onclick="javascript:funHSLinksd(9100119111,1)">محتوى عربي
  ';

		if ($lager == 'basher1985') {
			echo '  <input type="radio"  value="2" name="showcat"   onclick="javascript:funHSLinksd(9100119111,1)">المحتوى الاضافي ';
		}

		echo '</td>
  </tr>
<tr id=\'9100119111\' >
    <td width=\'25%\'>المحتوى الاضافي</td>
    <td width=\'50%\'>
	<input name=\'idrow2\'  type=\'checkbox\' value=\'indext\'>
	 القرآن الكريم
	 (يحتوي على    20
قارئ
	و 1521       
	تلاوة )
	<br>
		<input name=\'idrow3\'  type=\'checkbox\' value=\'indext\'>
	الخطب والدروس	 (يحتوي على 95          
محاضر
	و 1908       
	محاضرة )
	<br>
	
		<input name=\'idrow8\' ';
		echo ' type=\'checkbox\' value=\'indext\'>
	 الاناشيد	 (يحتوي على    34
شريط	و 265       
	نشيدة)
	<br>
	
		<input name=\'idrow5\'  type=\'checkbox\' value=\'indext\'>
	 الفلاشات الاسلامية	 (يحتوى على     6       
قسم و87       
	فلاش)
	<br>
		<input name=\'idrow10\'  type=\'checkbox\' value=\'indext\'>
	 التواقيع الاسلامية	 (يحتوي على   
109       
	
	توقيع )
	<br>
	
		<input name=\'i';
		echo 'drow11\'  type=\'checkbox\' value=\'indext\'>
	 الخلفيات الاسلامية	 (يحتوي على    
103       
	
	صورة)
    
    
    	<br>
	
		<input name=\'idrow24\' checked=\'checked\'  type=\'checkbox\' value=\'indext\'>
     
	<br>
			<input name=\'idrow12\'  type=\'checkbox\' value=\'indext\'>
شاشات التوقف	 (يحتوى على   
24       
	
	شاشة)
	<br>
	</t';
		echo 'd>
  </tr>
</table><br />
<div align="center"><tr>
	<td class="submit-buttons" colspan="2" align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" /></td>
</tr>
</table><br />
</form>
 
';
	}


	if ($_GET['page'] == 2) {
		function entersql($filelise, $allplay = '', $allcat = '') {
			if ($allplay) {
				mysql_query( '' . 'UPDATE `cat` SET `allplay` = \'' . $allplay . '\',`allcat` = \'' . $allcat . '\' WHERE `cat`.`catid` =2 LIMIT 1 ;' );
			}

			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );

			if (substr( $contents, 0, 19 ) == 'mysql_query("INSERT') {
				$waaa = mysql_query( 'select * from cat order by catid desc limit 1' );

				while ($rowaa = mysql_fetch_row( $waaa )) {
					$catall = $rowaa[0] + 5;
				}

				$words = explode( 'mysql_query("INSERT', $contents );
				$i = 0;

				while ($i < count( $words )) {
					$wordsd = explode( '#-n3esa-', $words[$i] );
					$wordsdd = explode( '");', $wordsd[0] );
					eval( 'mysql_query("INSERT' . $wordsdd[0] . '");' );

					if ($wordsd[1]) {
						$pattern = '/\bexit[\s]*(\([^\)]*\))?[\s]*[;]?</i';
						eval( preg_replace( $pattern, '', $wordsd[1] ) );
					}

					++$i;
				}
			} 
else {
				$words = explode( '#-n3esa-', $contents );
				$i = 0;

				while ($i < count( $words )) {
					mysql_query( $words[$i] );
					++$i;
				}
			}

		}

		mysql_query( 'CREATE TABLE `linkat` (
  `id` int(11) NOT NULL auto_increment,
  `catsmktba` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `visible` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `counter` int(11) NOT NULL,
  `mediatype` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;' );

		if ($_REQUEST['showcat'] == 1) {
			entersql( 'cata.sql' );
		} 
else {
			if ($_REQUEST['showcat'] == 2) {
				entersql( 'caten.sql' );
				mysql_query( 'UPDATE `styles` SET `id` = \'346\' WHERE `styles`.`id` =236 LIMIT 1 ;' );
			} 
else {
				entersql( 'cati.sql' );

				if ($_REQUEST['idrow2']) {
					entersql( 'cat2.sql', 1518, 19 );
				}


				if ($_REQUEST['idrow3']) {
					entersql( 'cat3.sql', 1907, 85 );
				}


				if ($_REQUEST['idrow8']) {
					entersql( 'cat8.sql', 265, 34 );
				}


				if ($_REQUEST['idrow5']) {
					entersql( 'cat5.sql', 89, 6 );
				}


				if ($_REQUEST['idrow10']) {
					entersql( 'cat10.sql', 109, 2 );
				}


				if ($_REQUEST['idrow11']) {
					entersql( 'cat11.sql', 103, 0 );
				}


				if ($_REQUEST['idrow12']) {
					entersql( 'cat12.sql', 20, 0 );
				}


				if ($_REQUEST['idrow24']) {
					entersql( 'cat24.sql', 735, 0 );
				}

				entersql( 'cat4.sql', 1, 0 );
			}
		}

		$sitname = $_REQUEST['sitname'];
		$url = $_REQUEST['url'];

		if (!ereg( 'http', $url )) {
			$url = 'http://' . $url;
		}

		$email = $_REQUEST['email'];
		$w = '' . 'update setting set sitname=\'' . $sitname . '\' ,url=\'' . $url . '\' ,email=\'' . $email . '\'  where  id=\'1\'';

		if (!( $ww = mysql_query( $w ))) {
			exit( '?? ??? ??????? ?? ???' );
			(bool)true;
		}

		echo ' 	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التالية</span></th>
</tr>
</table>
<form action="?page=3"  name="myform" method="post">
<input type="hidden" value="';
		echo $_REQUEST['showcat'];
		echo '" name="showcat" />
<table cellpadding="3" cellspacing="1" width="60%" class="t_style_b" border="1" align="center">
<thead>
<tr>
	<th class="main1" align="center" colspan="2">اكتب معلومات المدير</th>
</tr>
</thead>


   <tr>
    <td width=147>اسم المستخدم</td>
    <td width="50%"><input name=\'user\' type=\'text\' value=\'\' size=\'33\'></td>
  </tr>
    <tr>
    <td width=147>كلمة المرور</td>
    <td ';
		echo 'width="50%"><input name=\'passnew1\' type=\'password\' value=\'\' size=\'33\'></td>
  </tr>
    <tr>
    <td width=147>كلمة المرور مرة اخرى</td>
    <td width="50%"><input name=\'passnew2\' type=\'password\' value=\'\' size=\'33\'></td>
  </tr>
      <tr>
    <td width=147>بريد المدير</td>
    <td width="50%"><input name=\'email\' type=\'text\' value=\'\' size=\'33\'></td>
  </tr>

</table><br />
<div align="center"><tr>
	<td class="sub';
		echo 'mit-buttons" colspan="2" align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" /></td>
</tr>
</table><br />
</form>
 
';
	}


	if ($_GET['page'] == 3) {
		if ($_REQUEST['showcat'] == 2) {
			$filelise = 'templatee.sql';
			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );
			$words = explode( '#-n3esa-', $contents );
			$i = 0;

			while ($i < count( $words )) {
				mysql_query( $words[$i] );
				++$i;
			}
		} 
else {
			$filelise = 'template.sql';
			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );
			$words = explode( '#-n3esa-', $contents );
			$i = 0;

			while ($i < count( $words )) {
				mysql_query( $words[$i] );
				++$i;
			}
		}

		$passnew2 = $_REQUEST['passnew2'];
		$passnew1 = $_REQUEST['passnew1'];
		$email = $_REQUEST['email'];
		$user = $_REQUEST['user'];

		if ($passnew1 == $passnew2) {
			$passnew2 = md5( md5( $passnew2 ) );
			$wdsd = '' . 'update user set name=\'' . $user . '\',email=\'' . $email . '\',pass=\'' . $passnew2 . '\' where id=\'1\'';

			if (!( mysql_query( $wdsd ))) {
				exit( 'dddd' );
				(bool)true;
			}
		}

		echo '	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التاليه</span></th>
</tr>
</table>
<form action="?page=4"  name="myform" method="post">
<input type="hidden" value="';
		echo $_REQUEST['showcat'];
		echo '" name="showcat" />

<div align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" />
</form>
 
';
	}


	if ($_GET['page'] == 4) {
		if ($_REQUEST['showcat'] != 2) {
			$filelise = 'styles.sql';
			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );
			$words = explode( '#-n3esa-', $contents );
			$i = 0;

			while ($i < count( $words )) {
				mysql_query( $words[$i] );
				++$i;
			}
		}

		$filelise = 'salat.sql';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( '#-n3esa-', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		mysql_query( 'INSERT INTO block VALUES (139,"???,1,"","<table align=\"center\" style=\"width: 95%;margin-top:10px;margin-bottom:10px\">	<tr>		<td align=\"center\">		<p>		<a style=\"text-decoration: none\" target=\"_blank\" href=\"rss.xml\">		<img src=\"images/Feed.png\" alt=\"RSS\" style=\"height: 35px; border-style: solid; border-width: 0\" width=\"35\" /></a></p>			</td>		<td align=\"center\">		<p><a target=\"_blank\" href=\"#\">		<img src=\"images/Twitter.png\" alt=\"Twitter\" height=\"35\" width=\"35\" style=\"border-width: 0\" /></a></p>				</td>		<td align=\"center\">		<p>		<a style=\"text-decoration: none\" target=\"_blank\" href=\"#\">		<img src=\"images/FaceBook.png\" alt=\"Facebook\" height=\"35\" width=\"35\" style=\"border-width: 0\" /></a></p>				</td>		<td align=\"center\">		<p><a target=\"_blank\" href=\"#\">		<img src=\"images/Youtube.png\" alt=\"Youtube\" height=\"35\" width=\"35\" style=\"border-width: 0\" /></a></p>			</td>	</tr></table>",1,1,"","");' );
		echo '	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التاليه</span></th>
</tr>
</table> 
<form action="?page=5"  name="myform" method="post">

<div align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" />
</form>
 
';
	}


	if ($_GET['page'] == 5) {
		$filelise = 'ips.sql';
		mysql_query( 'CREATE TABLE ips (
  ips bigint(20) NOT NULL default \'0\',
  `code` char(2) NOT NULL default \'\',
  UNIQUE KEY ips (ips)
) ENGINE=MyISAM DEFAULT CHARSET=cp1256;' );
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( ';', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		echo '	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التاليه</span></th>
</tr>
</table>
<form action="?page=6"  name="myform" method="post">

<div align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" />
</form>
 
';
	}


	if ($_GET['page'] == 6) {
		$filelise = 'ips2.sql';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( ';', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		echo '	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التالية</span></th>
</tr>
</table>
<form action="?page=7"  name="myform" method="post">

<div align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" />
</form>
 
';
	}


	if ($_GET['page'] == 7) {
		$filelise = 'ips3.sql';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( ';', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		echo '	<table cellpadding="0" cellspacing="1" width="60%"  border="1" align="center">

<tr>
	<th align="center" colspan="2">
	';
		echo '<s';
		echo 'pan lang="ar-kw" style="color: #FF0000; font-size: large">الخطوة التاليه</span></th>
</tr>
</table>
<form action="?page=end"  name="myform" method="post">

<div align="center">
	<input class="submit" type="submit" value="استمرار" name="submit" accesskey="s" />
</form>
 
';
	}


	if ($_GET['page'] == 'end') {
		$filelise = 'ips4.sql';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$words = explode( ';', $contents );
		$i = 0;

		while ($i < count( $words )) {
			mysql_query( $words[$i] );
			++$i;
		}

		echo '
<form action="../index.php"  name="myform" method="post">
<table cellpadding="3" cellspacing="1" width="60%" class="t_style_b" border="1" align="center">
<thead>
<tr>
	<th class="main1" align="center" colspan="2">تم التثبيت بنجاح - xdecoderx</th>
</tr>
</thead>


   <tr>
    <td ><p align=\'center\'>
        مبروك التركيب - xdecoderx<br>
        <br><font color=\'#FF0000\'>الرجاء حذف مجلد ال';
		echo '<s';
		echo 'pan lang=\'en-us\'>install<br>
        <br>   <font color=\'#FF0000\'>يجب اعطاء المجلد uplaod الترخيص 777 اذ لم يكن كذلك<br>
<font color=\'#FF0000\'><br></td>
  

</table><br />
<div align="center"><tr>
	<td class="submit-buttons" colspan="2" align="center">
	<input class="submit" type="submit" value="انهاء" name="submit" accesskey="s" /></td>
</tr>
</table><br />
</form>
 
';
	}

	echo '


</div>';
?>