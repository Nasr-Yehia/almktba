//PART (1)
// set maximum of backgrounds images (the images should be in 'gif' format and it's FileName is as number (1,2,3 ...) sequencially
var imageCount = 50;

//PART (2)
initializeTemplates("Simplified Arabic|||3|||0|||1||||||23|||4|||3|||13|||0|||0|||1|||0|||1|||0");
initializeTemplates("Simplified Arabic|||3|||1|||5|||backgrounds/23.gif|||23|||1|||3|||5|||0|||0|||2|||0|||1|||0");
initializeTemplates("Simplified Arabic|||3|||0|||0||||||2|||6|||3|||26|||0|||0|||0|||0|||1|||1");
initializeTemplates("Simplified Arabic|||3|||0|||1||||||9|||2|||8|||22|||0|||0|||2|||0|||1|||1");
initializeTemplates("Simplified Arabic|||3|||1|||1|||backgrounds/21.gif|||0|||3|||5|||10|||0|||0|||2|||0|||1|||0");
initializeTemplates("Simplified Arabic|||3|||1|||0|||backgrounds/27.gif|||0|||4|||5|||6|||0|||0|||2|||0|||1|||0");






//PART (3)
loadTemplate(0);
