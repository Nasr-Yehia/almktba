/***** Youm7 Global Browser Sniffing Variables *****/
var Youm7_isopera = typeof window.opera != 'undefined';
var Youm7_isie = typeof document.all != 'undefined'
   	&& !Youm7_isopera && navigator.vendor != 'KDE';
var Youm7_issafari = navigator.vendor == 'Apple Computer, Inc.';


/***** ^^^ Youm7 Global Functions ^^^ *****/
/* Adds a function for the window load event */
function Youm7_callFunctionOnWindowLoad (functionToCall)
{
  if (typeof window.addEventListener != 'undefined')
  {
    window.addEventListener ('load', functionToCall, false);
  }
  else if (typeof document.addEventListener != 'undefined')
  {
    document.addEventListener ('load', functionToCall, false);
  }
  else if (typeof window.attachEvent != 'undefined')
  {
    window.attachEvent ('onload', functionToCall);
  }
  else
  {
    var oldFunctionToCall = window.onload;
    if (typeof window.onload != 'function')
    {
      window.onload = functionToCall;
    }
    else
    {
      window.onload = function ()
      {
        oldFunctionToCall ();
        functionToCall ();
      };
    }
  }
}

/* Calls functionToCall as soon as the targetElement is loaded, even if the document hasn't completely loaded yet. 
   Place the parameter list for functionToCall in order after Youm7_callFunctionOnElementLoad (targetId, functionToCall),
   e.g., Youm7_callFunctionOnElementLoad (targetId, functionToCall, parameter1, parameter 2, parameter 3, ...) */  
function Youm7_callFunctionOnElementLoad (targetId, functionToCall)
{
	var myArguments = arguments;
	Youm7_callFunctionOnWindowLoad (function ()
		{
			window.loaded = true;
		});
	var targetElement = document.getElementById (targetId);
	if (targetElement == null && !window.loaded)
	{
		var pollingInterval = setInterval (function ()
			{
				if (window.loaded)
				{
					clearInterval (pollingInterval);
				}
				targetElement = document.getElementById (targetId);
				if (targetElement != null)
				{
					clearInterval (pollingInterval);
					var argumentsTemp = new Array ();
					var argumentsTempLength = myArguments.length - 2;
					for (var i = 0; i < argumentsTempLength; i++)
					{
						argumentsTemp [i] = myArguments [i + 2];
					}		
					functionToCall.apply (this, argumentsTemp);
				}
			}, 10);
	}
}



/* Attaches an event handling function to the targetElement. 
   Examples of eventType values are 'mouseover' and 'keyup', as opposed to 'onmouseover' and 'onkeyup'. 
   bubbleEventUpDOMTree is a boolean variable specifying whether the event should activate the event listeners
   of all the ancestors of the element (up to the window object) */
function Youm7_addEventHandler (targetElement, eventType, functionToCall, bubbleEventUpDOMTree)
{
  if (!targetElement)
  {
	  window.status = 'Warning: Tried to attach event to null object';
	  return false;
  }
  if (typeof targetElement.addEventListener != 'undefined')
  {
    targetElement.addEventListener (eventType, functionToCall, bubbleEventUpDOMTree);
  }
  else if (typeof targetElement.attachEvent != 'undefined')
  {
    targetElement.attachEvent ('on' + eventType, functionToCall);
  }
  else
  {
    eventType = 'on' + eventType;
    if (typeof targetElement [eventType] == 'function')
    {
      var oldListener = targetElement [eventType];
      targetElement [eventType] = function ()
      {
        oldListener ();
        return functionToCall ();
      }
    }
    else
    {
      targetElement [eventType] = functionToCall;
    }
  }

  return true;
}

/* Begin Main story module */
var currPic=0;
var timer1, timer2;
var paused = true;
var opacity = 100;
var msDivs = new Array(4);
var msButtons = new Array(4); 
var msWrap;
var button;
var position;
var currPosition;

function initPageComponents() {
 /*  Used to load all components on the page */
 msDivs[0] = document.getElementById('mainStory1');
 msDivs[1] = document.getElementById('mainStory2');
 msDivs[2] = document.getElementById('mainStory3');
 msDivs[3] = document.getElementById('mainStory4');
 msButtons[0] = document.getElementById('a1'); 
 msButtons[1] = document.getElementById('a2');
 msButtons[2] = document.getElementById('a3');
 msButtons[3] = document.getElementById('a4');
 msWrap = document.getElementById('TopStoriesWrap');
 initPausePlayEvents();
 var breakingNews = document.getElementById('breakingNewsImg'); 
 if (breakingNews == null)
 {
  paused = false; 
  timer1=setTimeout('timedStory()',7000);
 }
   doImageSwap();
}

function initPausePlayEvents() {
 /* add Event Handlers for the Photo Module */
 if (!document.getElementById || !document.getElementsByTagName) {
  return true;
 }
 /* checks for Javascript operability  */ 

 /*  get all the links in the photo module  */
 var topStories = document.getElementById('TopStoriesTitles');
 var links = topStories.getElementsByTagName('a');

 for (i=0;i < links.length; i++) {
  if (links.item(i).id.substring(0,1) == 'a'){  
   //filter the links for those that have a class name beginnig with 'a'
   //add the doNumber event handler for the number links
   links.item(i).href='javascript:{}';
   Youm7_addEventHandler (links [i], 'click', function (event)
   {
    doNumber (event);
   }, false);
  }
 }
 
 var playLink = document.getElementById('playLink');
  
 //add the doButton event handler for the play pause button 
 Youm7_addEventHandler ( playLink , 'click', function (event)
 {
  doButton (event);
 }, false);
}

/* helper function to deal specifically with images and the cross-browser differences in opacity handling */
function fader(opac) {
 if (msWrap.style.MozOpacity!=null) {  
  /* Mozilla's pre-CSS3 proprietary rule */ 
  msWrap.style.MozOpacity = (opac/100) - .001;
 } else if (msWrap.style.opac!=null) {
  /* CSS3 compatible */
  msWrap.style.opacity = (opac/100) - .001;
 } else if (msWrap.style.filter!=null) {
  /* IE's proprietary filter */ 
 if (opac==100){
  msWrap.style.filter = "none;";
 } else {
  msWrap.style.filter = "alpha(opacity="+opac+");";
      }
 }
}

function change(num, step) {
 /*fadeOut*/
 if (step == 1) {
  opacity -= 10;
  if (opacity > 0) {
   fader(opacity);
   timer2=setTimeout('change(' + num + ', 1)',30);
  }
  else { 
   change(num, 2);
  }
 }
 /*change picture*/
 else if (step == 2) {
  currPic = num;
  msDivs[0].style.display = (num == 0 ? "block" : "none"); 
  msDivs[1].style.display = (num == 1 ? "block" : "none"); 
  msDivs[2].style.display = (num == 2 ? "block" : "none");
  msDivs[3].style.display = (num == 3 ? "block" : "none");
  msButtons[0].className = (num == 0 ? "on" : "off");
  msButtons[1].className = (num == 1 ? "on" : "off");
  msButtons[2].className = (num == 2 ? "on" : "off"); 
  msButtons[3].className = (num == 3 ? "on" : "off");
  change(num, 3);
 }
 /*fadeIn*/
 else if (step == 3) { 
  opacity += 10;
  if (opacity <= 100) {
   fader(opacity);
   timer2=setTimeout('change(' + num + ', 3)',30);
  }
 }
}

/* change picture, wait 5 seconds, repeat */
function timedStory() {
 if (currPic<3)
 currPic++;
 else
 currPic=0;
 
 change(currPic, 1);
 timer1=setTimeout('timedStory()',7000);

 
/* else{
	currPic=0;
	clearTimeout(timer1);
	change(currPic,1);
	paused = true;
	doImageSwap();
 }*/
 
}

/* executed when the play pause button is selected */
function doButton(event) {
 paused = !paused;
 doImageSwap();
 if (paused) {
  /* stop the image loop */
  clearTimeout(timer1);
 }
 else { 
  /* restart the image loop */
  timedStory();
 }
}  


/*executed when a number link is selected */
function doNumber (event) {
 var eventSource = typeof event.target != 'undefined' ? event.target : window.event.srcElement;
 /*  get the number portion of the class name of the event source */ 
 currPic = eventSource.id.substring(1,2) - 1;
 paused = true;
 doImageSwap();
 clearTimeout(timer1);
 clearTimeout(timer2);
 change(currPic, 1);

} 

/* swap the play pause button image */
function doImageSwap() {
		 var button = document.getElementById('playLink'); 
		 if (!Youm7_isie){
		  var imageFile = paused ? "http://img.timeinc.net/time/i/btn_play.gif" : "http://img.timeinc.net/time/i/btn_pause.gif";
		  button.style.background= "url("+imageFile+") 0px 0px no-repeat"; 	
		 }else{
		  /*  Use an image sprite to deplete the image flickering in IE */
		  button.style.backgroundImage= "url(http://img.timeinc.net/time/i/btn_playpause.gif)";
		  position = paused ? "-16 px" : "0 px";  /* change the image source */
		  try {
			  document.execCommand('BackgroundImageCache', false, true);
			} catch(e) {}
				
			  /* if paused and play is not displayed */
			  if (paused == true && currPosition != "-16 px"){
				  button.style.backgroundPositionY=position;
			  }
			  /* if playing and paused is not displayed */
			  if (paused != true && currPosition != "0 px"){
				  button.style.backgroundPositionY=position;			  
			 }  
		 currPosition = position;
		 }
}  
/* End Main story module */




/* Initialization and Unobtrusive Javascript Calls */
Youm7_callFunctionOnElementLoad('playLink', initPageComponents);

