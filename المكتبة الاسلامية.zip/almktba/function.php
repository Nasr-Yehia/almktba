<?php
/**
* @ iDezender 7.0
* @ Developed by Qarizma
*
* @    Visit our website:
* @    www.iRadikal.com
* @    For cheap decoding service :)
* @    And for the ionCube Decoder!
*/          

	function onlined($title, $titl, $tit) {
		$rowarray = mysql_query( 'select sitname from  setting  where ba=\'settingtime\'   LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$timeoutseconds = '3000';

		if (!$rowarray['sitname']) {
			$timeoutseconds = $rowarray['sitname'];
		}

		$time = time(  );
		$timeout = $time - $timeoutseconds;
		mysql_query( '' . 'DELETE FROM online WHERE time < ' . $timeout );
		$www = mysql_query( '' . 'select * from online WHERE ip=INET_ATON(\'' . $_SERVER['REMOTE_ADDR'] . '\')   LIMIT 0,1 ' );
		$teet = mysql_num_rows( $www );

		if ($teet == 1) {
			mysql_query( 'UPDATE online SET time=\'' . time(  ) . ( '' . '\' ,file =\'' . $title . '\' ,user=\'' . $_SESSION['user'] . '\' ,no3=\'' . $titl . '\' ,nampage =\'' . $tit . '\' WHERE ip=INET_ATON(\'' . $_SERVER['REMOTE_ADDR'] . '\')  LIMIT 1 ' ) );
			return null;
		}

		$check = mysql_query( 'SELECT * FROM `ips` LIMIT 0,1' );

		if ($check) {
			$qryd = mysql_query( '' . 'SELECT * FROM ips WHERE ips <= INET_ATON(\'' . $_SERVER['REMOTE_ADDR'] . '\') ORDER BY ips DESC LIMIT 0,1' );
			$ndqryd = mysql_num_rows( $qryd );

			while ($rowsd = mysql_fetch_row( $qryd )) {
				$country_code = strtolower( $rowsd[1] );
			}


			if ($ndqryd == 0) {
				$country_code = 'unknown';
			}

			$sql_country = mysql_query( '' . 'SELECT * FROM countries WHERE code=\'' . $country_code . '\'   LIMIT 0,1 ' );
			$result_country = mysql_fetch_array( $sql_country );
		}

		mysql_query( 'INSERT INTO online VALUES (\'' . time(  ) . ( '' . '\',INET_ATON(\'' . $_SERVER['REMOTE_ADDR'] . '\'),\'' . $title . '\',\'' . $_SESSION['user'] . '\',\'' . $titl . '\',\'' . $tit . '\',\'' . $result_country['country'] . '\',\'' . $country_code . '\')' ) );
	}

	function date_enter($timestamp = '') {
		if (@stristr( '/', $timestamp )) {
			return $timestamp;
		}

		$rowarray = mysql_query( 'select email from  setting where id=\'2\'   LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$format = $rowarray['email'];

		if ($timestamp) {
			if ($timestamp == 0) {
				$timestamp = time(  );
			}

			$rowarray = mysql_query( 'select msgclose,sl,msgurl from  setting  where ba=\'settingtime\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$rowarrays = mysql_query( 'select timeout from user where name=\'' . $_SESSION['user'] . '\'    LIMIT 0,1 ' );
			$rowarrays = mysql_fetch_array( $rowarrays );

			if ($rowarrays['timeout']) {
				$rowarray['sl'] = $rowarrays['timeout'];
			}


			if (substr( $rowarray['sl'], 0, 1 ) == '+') {
				$timestamp = $timestamp + substr( $rowarray['sl'], 1, 10 );
			} 
else {
				if (substr( $rowarray['sl'], 0, 1 ) == '-') {
					$timestamp = $timestamp - substr( $rowarray['sl'], 1, 10 );
				}
			}


			if ($rowarray['msgclose']) {
				include( 'class/DataH.php' );
			}


			if (!$str) {
				$str = $format;
			}

			return date( $str, $timestamp );
		}

	}

	function url_cat($htmlorphp, $row1D, $com) {
		if ($htmlorphp == 1) {
			if ($com) {
				$urlcatd = '' . 'cat-' . $com . '-' . $row1D . '.html';
			} 
else {
				$urlcatd = '' . 'catsmktba-' . $row1D . '.html';
			}
		} 
else {
			$urlcatd = 'catplay.php?ca' . 'ts' . 'mk' . ( '' . 'tba=' . $row1D );
		}

		return $urlcatd;
	}

	function filler($text) {
		$text = htmlspecialchars( $text );
		$text = str_replace( 'select', '', $text );
		$text = str_replace( 'update', '', $text );
		$text = str_replace( 'insert', '', $text );
		$text = str_replace( 'where', '', $text );
		$text = str_replace( 'like', '', $text );
		$text = str_replace( 'and', '', $text );
		$text = str_replace( 'set', '', $text );
		$text = str_replace( 'into', '', $text );
		$text = preg_replace( '/\'\/<>\'/', '', $text );
		$text = strip_tags( $text );
		return $text;
	}

	function block_r($styleid = '') {
		global $catsmktba;
		global $styleid;

		$rttl = 0;
		$w = mysql_query( 'select * from block where rtl=\'1\'  and showcat=\'1\' and( showright=\'\' or showright=\'-t\' or showright not LIKE \'%-' . $catsmktba . '%\' )   order by ratteb asc' );

		while ($rowr = mysql_fetch_row( $w )) {
			if ($rowr[6] == 0) {
				block1up( $rowr[1], $styleid, $left );
			}

			block_block( $rowr[0], stripslashes( $rowr[4] ), $styleid );

			if ($rowr[6] == 0) {
				block1down( $styleid );
			}

			$rttl = $rttl + 1;

			if ($rttl == 1) {
				ads_M( $catsmktba, '3' );
				continue;
			}
		}

	}

	function block_l($styleid) {
		$rttl = 0;
		$wr = mysql_query( 'select * from block where rtl=\'2\' and showcat=\'1\' order by ratteb asc' );

		while ($rowr = mysql_fetch_row( $wr )) {
			if ($rowr[6] == 0) {
				block1up( $rowr[1], $styleid, 'left' );
			}

			block_block( $rowr[0], stripslashes( $rowr[4] ), $styleid );

			if ($rowr[6] == 0) {
				block1down( $styleid, 'left' );
			}

			$rttl = $rttl + 1;

			if ($rttl == 1) {
				ads_M( '', '4' );
				continue;
			}
		}

	}

	function ads_M($cat = '', $id = '', $ruter = '') {
		if (!$cat) {
			$cat = 'all';
		}


		if (!$id) {
			$id = '1';
			$rowarray = mysql_query( 'select close,sl from  setting where ba=\'settingads\'   LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$center = ' style="text-align: center" valign="top"';

			if ($rowarray['close'] == 1) {
				echo '<div align="center">';
				ads_M( $cat, 1 );
				echo '</div>';
				return null;
			}


			if ($rowarray['close'] == 2) {
				echo '<div align="center"><table style="width: 100%"><tr>';
				echo '	<td ' . $center . '>' . ads_M( $cat, 1, 'ok' ) . '</td>';

				if ($rowarray['sl'] == 1) {
					echo '<tr></tr>';
				}

				echo '	<td ' . $center . '>' . ads_M( $cat, 6, 'ok' ) . '</td>';
				echo '</tr></table></div>';
				return null;
			}


			if ($rowarray['close'] == 3) {
				echo '<div align="center"><table style="width: 100%"><tr>';

				if ($rowarray['sl'] == 3) {
					$colspan1 = '  colspan="2"';
				}

				echo '	<td ' . $center . $colspan1 . '>' . ads_M( $cat, 1, 'ok' ) . '</td>';

				if ($rowarray['sl'] == 3) {
					echo '<tr></tr>';
				}

				echo '	<td ' . $center . '>' . ads_M( $cat, 6, 'ok' ) . '</td>';

				if (( $rowarray['sl'] == 4 || $rowarray['sl'] == 5 )) {
					echo '<tr></tr>';
				}


				if ($rowarray['sl'] == 5) {
					$colspan3 = '  colspan="2" ';
				}

				echo '	<td ' . $center . $colspan3 . ' >' . ads_M( $cat, 7, 'ok' ) . '</td>';
				echo '</tr></table></div>';
				return null;
			}
		} 
else {
			$www = mysql_query( '' . 'select * from ads WHERE  idplay=\'' . $id . '\'  and( comment=\'all\' or comment LIKE \'%' . $cat . '%\' ) and show1=\'\' order by rand()  LIMIT 0,1 ' );
			$teet = mysql_num_rows( $www );

			if ($teet != 0) {
				while ($Ads = @mysql_fetch_array( $www )) {
					$text = '<div align="center">';

					if ($Ads[6]) {
						$text .= '' . '<a target="blank" href="Bennar.php?ads=go&BennarID=' . $Ads['0'] . '">';
					}

					$email = explode( '||', $Ads[4] );

					if ($email[1]) {
						$WD = ( '' . 'width="' . $email['1'] . '"' );
					}


					if ($email[2]) {
						$HD = ( '' . 'height="' . $email['2'] . '"' );
					}


					if (!@stristr( '.swf', $Ads[4] )) {
						$text .= '' . '<img   alt="' . $Ads['2'] . '" ' . $HD . ' ' . $WD . ' src="' . $email['0'] . '" border=0>';
					} 
else {
						$text .= '' . ' <embed  ' . $HD . '  ' . $WD . '  src="' . $email['0'] . '">';
					}


					if ($Ads[6]) {
						$text .= '</a>';
					}

					$text .= '</div>';
					mysql_query( '' . 'update ads set date= date + 1 where id=\'' . $Ads['0'] . '\' LIMIT 1' );

					if ($ruter) {
						return $text;
					}

					echo $text;
				}
			}
		}

	}

	function enterlogin($pageold = '') {
		$dsdsd = '<form method="POST" action="user.php?action=login">
  <table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td width="100%" colspan="2">
        <div align="right"><font class="fonttable">: ��� �������� </font></div></td></tr><tr><td width="100%" colspan="2">
                <div align="right"><input type="text" dir="rtl" name="UserName" size="40"></div></td></tr><tr><td width="100%" colspan="2">    <div align="right"><font  class="fonttable">:  ��������� ����������  </font></div></td></tr><tr>
        <td width=100% colspan=\'2\'>
        <div align="right"><input dir="rtl" type="password" name="Password" size="40"></div></td></tr><tr><td width="50%"><a  class="linktable" href="user.php?action=usergot">�� ���� ���� �����ѿ</a></td><td width="50%"><div align=right><font  class="fonttable2">������ <input name="remmber" type="checkbox" value="ON"></div></td>
                </tr><tr><td width=100% colspan="2">
                <div align="center"><input type="submit" value="����� ������" name="SignIn"></div></td></tr>
                <tr><td width=100% colspan="2">
                <div align="right" dir=rtl><font class="fonttable2"> � ����� ���� <a  class="linktable" href="user.php?action=reg"> ������� </a> <font class="fonttable2"> ����� ��� ������ .</div></td></tr></table>';

		if ($pageold) {
			$dsdsd .= '' . ' <input name="pageold" type="hidden" value="' . $pageold . '"> ';
		} 
else {
			$dsdsd .= '<input name="pageold" type="hidden" value="' . $_SERVER['REQUEST_URI'] . '">  ';
		}

		$dsdsd .= ' </form>';
		return $dsdsd;
	}

	function generatekeywords($keys) {
		$keys = preg_replace( '/<[^>]*>/', ' ', $keys );
		$keys = preg_replace( '/[\.;:|\'|\"|\`|\,|\(|\)|\-]/', ' ', $keys );
		$keys = str_replace( '
', ' ', $keys );
		$keys = str_replace( '
', ' ', $keys );
		$keysArray = explode( ' ', $keys );
		shuffle( $keysArray );
		$keysArray = array_count_values( array_map( 'strtolower', $keysArray ) );
		foreach ($keysArray as $word => $instances) {
			if (3 <= strlen( trim( $word ) )) {
				$keywords .= '<a href="tags-' . $word . '.html">' . $word . '</a>' . ' , ';
				++$i;
				continue;
			}
		}

		$keywords = rtrim( $keywords, ', ' );
		return $keywords;
	}

	function close_dd($styleid) {
		$wwwz = mysql_query( '' . 'select * from comment WHERE name=\'' . $_SERVER['REMOTE_ADDR'] . '\' and msg=\'ips\'   LIMIT 0,1 ' );
		$teetz = mysql_num_rows( $wwwz );

		if ($teetz == 1) {
			$titlemain = '������ ����';
			echo ' <div align="center"><table border=0 width=45%><tr><td>';
			do_html_2( '����  ', '<font class="fonttable2">��� ��� ���� ������ ....   ���� ����  </font>', $styleid );
			echo '</td></tr></table></div>';
			template( $styleid, '' );
			exit(  );
		}

		$rowarray = mysql_query( 'select close,msgclose from  setting where id=\'1\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$close = $rowarray['close'];
		$msg = stripslashes( $rowarray['msgclose'] );
		$rowarray = mysql_query( 'select template from cat where catid=\'1\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$templat = explode( '<mktbatemplate>', $rowarray['template'] );
		$www = mysql_query( 'select * from  setting where ba=\'closeerror\'' );
		$teet = mysql_num_rows( $www );

		if (( 0 < $teet || file_exists( 'images/homeold2222.png' ) )) {
			if (!file_exists( 'images/homeold2222.png' )) {
				$filelise = './images/home.png';
				$fd = fopen( $filelise, 'r' );
				$contents = fread( $fd, filesize( $filelise ) );
				fclose( $fd );
				$up_yes = fwrite( $file, $dump_buffer );
				$fp = @fopen( 'images/homeold2222.png', 'x+' );
				$file = fopen( 'images/homeold2222.png', 'w' );
				$up_yes = fwrite( $file, $contents );
				fclose( $file );
			}

			exit( '<br><div align=center><big>xxx<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
		}


		if ($close == '1') {
			$titlemain = '������ ����';
			do_html_2( '!!  ������ ����', $msg, $styleid );
			echo '' . '<div align="center">' . $rowas['5'] . '</div>';
			template( $styleid, '' );
			exit(  );
		}


		if (( !$_SESSION['user'] && $close == '3' )) {
			errologi(  );
		}

	}

	function mobile($ok = '') {
		if (( $_SESSION['stylejawal'] == 'ok' || preg_match( '/(iphone|ipod\/blackberry|configuration\/cldc|hp |hp-|htc |htc_|htc-|iemobile|kindle|midp|mmp|motorola|mobile|nokia|android|opera mini|opera mobi|palm|palmos|pocket|portalmmm|ppc;|smartphone|sonyericsson|sqh|spv|symbian|treo|up.browser|up.link|vodafone|windows ce|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'] ) )) {
			$rowarray = mysql_query( 'select close from  setting  where ba=\'settingjawal\'   LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );

			if ($ok) {
				return true;
			}


			if ($_SESSION['stylejawal'] == 'none') {
				return false;
			}


			if (( $rowarray['close'] == 3 || preg_match( '/ipad/i', $_SERVER['HTTP_USER_AGENT'] ) )) {
				return false;
			}

			return true;
		}

	}

	function startpage_M($styleid = '', $titlemain = '', $catsmktba = '', $action = '', $catid = '', $keywords = '', $description = '', $imageplay = '') {
		$titlemain = str_replace( '�', '', $titlemain );
		$w = mysql_query( 'select * from  setting where id=\'1\'  LIMIT 0,1 ' );

		while ($row = mysql_fetch_row( $w )) {
			$close = $row[4];
			$msg = $row[5];
			$title = $row[3];
			$urlll = $row[7];
			$urlname = $row[3];
		}

		$rowarray = mysql_query( 'select mosahm from  cat  where catid=\'1\'' );
		$rowarray = mysql_fetch_array( $rowarray );
		$usrl = getenv( 'SERVER_NAME' );
		$usrl = str_replace( 'www.', '', $usrl );
		$timee = 86400;
		$usrld = explode( '.', $usrl );
		$ip = getenv( 'REMOTE_ADDR' );
		$filelise = './lisen.date';
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$entries = explode( ',', $contents );
		$entriess = explode( '=', $entries[1] );

		if ($rowarray['mosahm'] < time(  ) - $timee * 3) {
			$letters = '12345678902646465498';
			$letters = substr( str_shuffle( $letters ), 0, 8 );
			$url = 'http://mktba.org/select.php?action=select&dominold=' . $entries[0] . '&dominnew=' . $usrl . '&ip=' . $letters;
			$url = url_curl( $url );
			mysql_query( 'update cat set mosahm=\'' . time(  ) . ( '' . '\',addcom=\'' . $letters . '\'   where catid=\'1\' LIMIT 1' ) );
		}


		if ($_SESSION['user']) {
			mysql_query( 'update user set reglog=\'' . time(  ) . '\'  where name=\'' . $_SESSION['user'] . '\'  LIMIT 1 ' );
		}

		$rowarray = mysql_query( 'select url from  setting where id=\'2\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$commurl = explode( '|-|', $rowarray['url'] );

		if (!$keywords) {
			$keywords = $commurl[0];
			$description = $commurl[1];
		}

		$keywords = preg_replace( '/<[^>]*>/', ' ', $keywords );
		$keywords = str_replace( '
', ' ', $keywords );
		$keywords = str_replace( '
', ' ', $keywords );
		$keywords = preg_replace( '/[\.;:|\'|\"|\`|\,|\(|\)|\-]/', ' ', $keywords );
		$words = explode( ' ', $keywords );
		$i = 0;

		while ($i < count( $words )) {
			$newtext = $words[$i];

			if ($newtext != '') {
				$commurld .= '' . $newtext . ' ,';
			}

			++$i;
		}


		if ($catsmktba == 'index') {
			$titlrl = '';
		} 
else {
			$titlrl = '' . $titlemain . ' -';
		}

		$description = preg_replace( '/<[^>]*>/', ' ', $description );
		$description = str_replace( '
', ' ', $description );
		$description = str_replace( '
', ' ', $description );
		$description = preg_replace( '/[\.;:|\'|\"|\`|\,|\(|\)|\-]/', ' ', $description );
		echo '' . '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
 <html xmlns="http://www.w3.org/1999/xhtml"  lang="ar-sa" dir="rtl">
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=windows-1256" />
 <title>  ' . $titlrl . ' ' . $title . '</title>
 <meta name="keywords" content=" ' . $commurld . '    " />
 <meta name="description"  content="' . str_replace( '
', '', $description ) . ( '' . '"/>
 <meta property="og:title" content="' . $titlrl . ' ' . $title . '"/>
 <meta property="og:image" content="' . $imageplay . '"/>
 <meta property="og:site_name" content="' . $titlemain . '"/>
 <meta property="og:description" content="' ) . str_replace( '
', '', $description ) . ( '' . '"/>
 <meta name="abstract" content=" ' . $titlemain . '  " />
 <meta name="refresh" content="83609" />
 <meta name="robots" content="index, follow" />
 <meta name="robots" content="all" />
 <meta name="revisit-after" content="1 hours" />
 <meta name="rating" content="General" />
 <meta name="distribution" content="Global" />
 <meta name="MSSmartTagsPreventParsing" content="true" />
 <meta http-equiv="Content-Language" content="AR" />
 <meta name="Expires" content="0" />
 <meta name="owner" content="aln3esa" />
 <meta name="classification" content="All" />
 <meta name="Copyright" content="����� ������� ��������� ������  ������� ���������" />
 <meta name="googlebot" content="archive" />  
 <meta name="resource-type" content="document" />
 <meta http-equiv="Cache-Control" content="Public" />
 <meta http-equiv="Pragma" content="No-Cache" />
' );
		$rowarray = mysql_query( 'select close,email from  setting where ba=\'settingcomment\'  limit 0,1' );
		$rowarray = mysql_fetch_array( $rowarray );

		if ($rowarray['close'] == 4) {
			echo '<meta property="fb:app_id" content="' . $rowarray['email'] . '">';
		}

		echo '' . '<link rel="alternate" type="application/rss+xml" title="' . $title . '" href="rss.xml" />
 ';
		$wss = mysql_query( 'select catid,catname,cat from cat where parentcatid=\'1\'  and ( showcat=\'1\' or  showcat=\'3\' ) order by ratteb asc' );

		while ($rowd = mysql_fetch_row( $wss )) {
			if (( ( $rowd[2] != 4 && $rowd[2] != 3 ) && $rowd[0] != 15 )) {
				echo '' . ' <link rel="alternate" type="application/rss+xml" title="' . $rowd['1'] . '" href="rss-' . $rowd['0'] . '.xml" /> ';
				continue;
			}
		}

		$rowarray = mysql_query( 'select msgurl  from  setting where id=\'1\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$htmlorphp = $rowarray['msgurl'];

		if ($htmlorphp == 1) {
			echo '<link rel="stylesheet" type="text/css" href="css-';
			echo $styleid;
			echo '.css" />';
		} 
else {
			echo '<link rel="stylesheet" type="text/css" href="css.php?styleid=';
			echo $styleid;
			echo '" />';
		}

		echo '<s';
		echo 'cript  type="text/javascript" src="ajax/include.js"></script></head> 
<body> ';

		if ($action != 'a3lan') {
			$rowarray = mysql_query( '' . 'select template1,login from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$templat = explode( '<mktbatemplate>', stripslashes( $rowarray['login'] ) );

			if ($templat[2]) {
				$searchs = $rowarray[1];
			}


			if (( $templat[0] && $templat[1] )) {
				if (!$_SESSION['user']) {
					$login = '<form method="post" action="user.php?action=login">  <input name="pageold" type="hidden" value="' . $_SERVER['REQUEST_URI'] . '">' . $templat[0] . '</form>';
				} 
else {
					$w = mysql_query( '' . 'select * from user where name=\'' . $_SESSION['user'] . '\'   LIMIT 0,1 ' );

					while ($rows = mysql_fetch_row( $w )) {
						$words = explode( '-', $rows[12] );
						$fov = count( $words ) - 1;
						$rows[10] = date( ' h:i  d-m-Y', $rows[10] );
						$resultonline = mysql_query( '' . 'select id from  comment where idplay=\'' . $_SESSION['iduser'] . '\' and msg=\'msguser\' and counter=1 ' );
						$msgs = mysql_num_rows( $resultonline );
						$resultonline = mysql_query( '' . 'select id from  comment where ( msg=\'file\' or  msg=\'fileerror\' ) and title=\'' . $_SESSION['user'] . '\' ' );
						$files = mysql_num_rows( $resultonline );
						$nameuser = $_SESSION['user'];
						$lashvist = $rows[10];
						eval( '$login= "' . str_replace( '"', '\"', stripslashes( $templat[1] ) ) . '";' );
					}
				}
			}

			$ads = ads_M( $catsmktba, '2', 'ok' );
			$ads2 = ads_M( $catsmktba, '8', 'ok' );
			$news = '' . '<script type="text/javascript" src="newplay.php?action=news&styleid=' . $styleid . '"></script>';
			$ahdaa = '' . '<script type="text/javascript" src="newplay.php?action=ahdaa&styleid=' . $styleid . '"></script>';
			$newplay = '' . '<script  type="text/javascript" src="newplay.php?styleid=' . $styleid . '"></script>';
			echo ' </head> ';

			if (mobile( 'ok' )) {
				echo '<div style="height: 60px;text-align: center;" dir=ltr>
 <a  style="   background: #fff6bf;text-align: center; padding:30px 200px 25px 200px;     border-top: 2px solid #ffd324;     border-bottom: 2px solid #ffd324; width: 127%; text-decoration: none;" href="index.php?mainiscreen=ok" > <font size="+2">������ ��� ���� ������ ���� ���</font></a>
</div>';
			}

			eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[template1] ) ) . '";' );
		}

	}

	function template($styleid = '', $action = '') {
		if ($action != 'a3lan') {
			$usrl = getenv( 'SERVER_NAME' );
			$usrl = str_replace( 'www.', '', $usrl );
			$timee = 86400;
			$usrld = explode( '.', $usrl );
			$filelise = './lisen.date';
			$fd = fopen( $filelise, 'r' );
			$contents = fread( $fd, filesize( $filelise ) );
			fclose( $fd );
			$entries = explode( ',', $contents );
			$entriess = explode( '=', $entries[1] );

			if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
				echo '<!-- ������ ��� ����� ������ ��� ���� �� ���� --><div align=\'center\'><b><small><a target=\'_blank\' href=\'http://www.mktba.org\' style=\'color: #000000; font-size: 10pt; font-weight: bold\'>Powered by: MktbaGold 6.4</a></small></b></div>';
			}

			$rowarray = mysql_query( 'select ba from  setting where id=\'2\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$rowsss = explode( '-', $rowarray[0] );

			if (( $rowsss[0] == 1 || ( $rowsss[0] == 3 && $_SESSION['user'] ) )) {
				echo '<div  align="right"> <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">&nbsp;<select  onchange="this.form.submit()" dir="rtl" name="styleidP">';
				$a = mysql_query( 'select name,id,show1 from    styles    where jawal=\'\' and show1!=1 order by id asc' );
				echo '<option>���� ��������</option> ';
				echo '<option  value=\'0\'>���������</option> ';

				while ($rows = mysql_fetch_row( $a )) {
					if ($rows[1] == $styleid) {
						$out = 'selected';
					}


					if (( $rows[2] == 2 || ( $rows[2] == 3 && $_SESSION['user'] ) )) {
						echo '' . '<option value=\'' . $rows['1'] . '\' ' . $out . '>' . $rows['0'] . '</option> ';
						$out = '';
						continue;
					}
				}

				echo '</select></form></div>';
			}

			$rowarray = mysql_query( 'select url from  setting where id=\'2\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$commurl = explode( '|-|', $rowarray['url'] );
			$keywords = $commurl[0];
			$description = $commurl[1];
			$keywords = generatekeywords( $keywords );
			$rowarray = mysql_query( 'select counter from cat where catid=\'1\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$totel = $rowarray['counter'];
			$resultonline = mysql_query( 'SELECT * FROM online ' );
			$online = mysql_num_rows( $resultonline );
			$rowarray = mysql_query( 'select sitname from  setting where id=\'1\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			$title = $rowarray['sitname'];
			$rowarray = mysql_query( '' . 'select template2 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[template2] ) ) . '";' );
		}

	}

	function a3lan_down($cat = '') {
		$was = mysql_query( 'select msgclose from  setting where id=\'2\'  LIMIT 0,1 ' );

		while ($rowas = mysql_fetch_row( $was )) {
			$rowas[5] = stripslashes( $rowas[0] );
			echo '' . '<div align="center">' . $rowas['5'] . '</div>';
		}

		ads_M( $cat, 5 );
	}

	function styleshow($styleid = '', $styleidP = '', $styleidG = '') {
		if ($styleidP == '0') {
			$styleid3 = '';
			$_SESSION['styleidid'] = '';

			if ($_SESSION['user']) {
				mysql_query( 'update user set styleid=\'\'  where name=\'' . $_SESSION['user'] . '\'' );
			}
		} 
else {
			$styleidG = filler( intval( $styleidG ) );

			if ($styleidG) {
				$styleid = $styleidG;
			} 
else {
				if ($styleidP) {
					$styleid = $styleidP;

					if ($_SESSION['user']) {
						mysql_query( '' . 'update user set styleid=\'' . $styleid . '\'  where name=\'' . $_SESSION['user'] . '\' LIMIT 1' );
					} 
else {
						$_SESSION['styleidid'] = $styleid;
					}
				} 
else {
					if ($styleid) {
						$styleid = $styleid;
					} 
else {
						if ($_SESSION['user']) {
							$w = mysql_query( 'select styleid from user where name=\'' . $_SESSION['user'] . '\'   LIMIT 0,1 ' );

							while ($rows = mysql_fetch_row( $w )) {
								$styleid = $rows[0];
							}
						} 
else {
							$styleid = $_SESSION['styleidid'];
						}
					}
				}
			}

			$a = mysql_query( '' . 'select  id,show1,jawal   from  styles where id=\'' . $styleid . '\'   LIMIT 0,1 ' );

			while ($row = mysql_fetch_row( $a )) {
				$styleid3 = $row[0];

				if (( $row[1] == 1 || ( $row[1] == 3 && !$_SESSION['user'] ) )) {
					$styleid3 = '';
				}


				if ($row[2]) {
					$_SESSION['stylejawal'] = 'ok';
					continue;
				}

				$_SESSION['stylejawal'] = null;
			}
		}


		if (!$styleid3) {
			if (mobile(  )) {
				$rowarray = mysql_query( 'select id   from  styles where show1=\'2\' and jawal!=\'\'   LIMIT 0,1 ' );
				$rowarray = mysql_fetch_array( $rowarray );
				$styleid = $rowarray['id'];
			} 
else {
				$rowarray = mysql_query( 'select template   from  setting where id=\'1\'   LIMIT 0,1 ' );
				$rowarray = mysql_fetch_array( $rowarray );
				$styleid = $rowarray['template'];
			}
		}

		return $styleid;
	}

	function do_html_2($title = '', $table = '', $styleid = '', $index = '') {
		global $styleid;

		$rowarray = mysql_query( '' . 'select table1,tableindex1,tableplay1 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (!mobile(  )) {
			eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
		} 
else {
			echo '<div id="content" class="content">';
		}

		echo $table;

		if (!mobile(  )) {
			$rowarray = mysql_query( '' . 'select table2,tableindex2,tableplay2 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
			$rowarray = mysql_fetch_array( $rowarray );
			eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
			return null;
		}

		echo '</div>';
	}

	function do_html_up($title = '', $styleid = '', $index = '') {
		$rowarray = mysql_query( '' . 'select table1,tableindex1,tableplay1 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (( $rowarray[1] && $index == 'index' )) {
			$rowarray[0] = $rowarray[1];
		}


		if (( $rowarray[2] && $index == 'play' )) {
			$rowarray[0] = $rowarray[2];
		}

		eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
	}

	function do_html_down($styleid = '', $index = '') {
		$rowarray = mysql_query( '' . 'select table2,tableindex2,tableplay2 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (( $rowarray[1] && $index == 'index' )) {
			$rowarray[0] = $rowarray[1];
		}


		if (( $rowarray[2] && $index == 'play' )) {
			$rowarray[0] = $rowarray[2];
		}

		eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
	}

	function block1($title, $block, $styleid = '', $left = '') {
		$rowarray = mysql_query( '' . 'select msgurl from  setting where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$templat = explode( '<mktbatemplate>', stripslashes( $rowarray['msgurl'] ) );
		$search = array( '{title}', '{block}' );
		$replace = array( '' . $title, $block );

		if (( $templat[4] && $left )) {
			$templat[1] = $templat[4];
		}

		echo str_replace( $search, $replace, $templat[1] );
	}

	function block1up($title, $styleid = '', $left = '') {
		$rowarray = mysql_query( '' . 'select block1,blockL1 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (( $rowarray[1] && $left )) {
			$rowarray[0] = $rowarray[1];
		}

		eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
	}

	function block1down($styleid = '', $left = '') {
		$rowarray = mysql_query( '' . 'select block2,blockL2 from  styles where id=\'' . $styleid . '\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if (( $rowarray[1] && $left )) {
			$rowarray[0] = $rowarray[1];
		}

		eval( 'echo "' . str_replace( '"', '\"', stripslashes( $rowarray[0] ) ) . '";' );
	}

	function a3lan_def_up() {
		$rowarray = mysql_query( 'select msgurl  from  setting where id=\'2\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );

		if ($rowarray['msgurl']) {
			echo '<div align="center">' . stripslashes( $rowarray['msgurl'] ) . '</div>';
		}

	}

	function block_block($rowr, $rowrc, $styleid) {
		$rowarray = mysql_query( 'select msgurl  from  setting where id=\'1\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$htmlorphp = $rowarray['msgurl'];
		$rowarray = mysql_query( 'select counter,template from cat where catid=\'1\'  LIMIT 0,1 ' );
		$rowarray = mysql_fetch_array( $rowarray );
		$titl = $rowarray['counter'];
		$templat = explode( '<mktbatemplate>', stripslashes( $rowarray['template'] ) );

		if (substr( $rowrc, 0, 9 ) == 'fileblock') {
			$words = explode( '-', $rowrc );
			$wordsdd = explode( 'php', $words[1] );

			if (file_exists( '' . 'blocks/' . $wordsdd['0'] . 'php' )) {
				$wordsddd = explode( '=', $wordsdd[1] );
				$wordsddd[0] = str_replace( '?', '', $wordsddd[0] );
				$wordsddd[0] = $wordsddd[1];
				include( '' . 'blocks/' . $wordsdd['0'] . 'php' );
				return null;
			}

			echo '' . '<font  class="fontblock">����� ��� ����� <br><b>' . $words['1'] . '</b></font>';
			return null;
		}


		if (substr( $rowrc, 0, 5 ) == 'block') {
			$blockpl = substr( $rowrc, 5, 3 );
			$templats = explode( '<aln3esa>', stripslashes( $rowrc ) );
			$sitt = explode( '||', $templats[0] );

			if (count( $sitt ) != 1) {
				$catid = $sitt[1];
				$com2 = $sitt[2];
				$title = $sitt[3];
				$yes = $sitt[4];
			} 
else {
				$catid = substr( $templats[0], 8, 3 );
				$com2 = substr( $templats[0], 11, 3 );
				$title = substr( $templats[0], 14, 2 );
				$yes = substr( $templats[0], 16, 2 );
			}

			$catid2 = explode( '-', $catid );

			if ($blockpl == 'pla') {
				include( 'class/BlockMP.php' );
				return null;
			}


			if (( $blockpl == 'cat' || $blockpl == 'tsn' )) {
				include( 'class/BlockMC.php' );
				return null;
			}
		} 
else {
			$add = mysql_query( '' . 'select * from  cat where cat=\'3\' and numplay=\'' . $rowr . '\'  order by ratteb DESC' );
			$teet = mysql_num_rows( $add );
			$wi = mysql_query( '' . 'select * from cat where parentcatid=\'1\' and ( showcat=\'1\' or  showcat=\'3\' ) and (   addcom=\'1' . $rowr . '\' or addcom=\'2' . $rowr . '\' or addcom=\'3' . $rowr . '\') order by ratteb asc' );
			$teetss = mysql_num_rows( $wi );

			if (( 0 < $teetss || 0 < $teet )) {
				echo '<DIV id=menu><UL id=menuList>';
				echo catsid( $wi );

				while ($rowss = mysql_fetch_row( $add )) {
					$name = $rowss[1];
					$catimag = 'images/cat/link.gif';

					if ($rowss[13]) {
						$catimag = $rowss[13];
					}

					$target = '';

					if ($rowss[3] == 2) {
						$target = 'target=_blank';
					}

					$comm = $rowss[7];
					$search = array( '{catimag}', '{name}', '{shm}', '{target}', '{submenu}', '{playaaa}', '{urlcat}' );
					$replace = array( $catimag, $name, $shm, $target, $submenu, $playaaa, $comm );
					$test1 = str_replace( $search, $replace, $templats[4] );
					echo $test1;
				}

				echo '</UL></DIV>';
			}

			echo $rowrc;
		}

	}

	function block_cat($styleid, $ratteb, $catsmktba) {
		$w = mysql_query( '' . 'select * from block where rtl=4 and showcat=\'' . $catsmktba . '\' and ratteb=\'' . $ratteb . '\' order by ratteb asc' );

		while ($rowr = mysql_fetch_row( $w )) {
			if ($rowr[6] == 0) {
				block1up( $rowr[1], $styleid, 'left' );
			}

			block_block( $rowr[0], stripslashes( $rowr[4] ), $styleid );

			if ($rowr[6] == 0) {
				block1down( $styleid, 'left' );
				continue;
			}
		}

	}

	function errologi($ok = '') {
		global $styleid;

		$titlemain = '����� ������';
		echo ' <div align="center"><table border=0 width=45%><tr><td>';
		do_html_2( '����� ������ ', '<font class="fonttable2">��� ��� ���� ������ ....   ������� ���  </font>' . enterlogin(  ), $styleid );
		echo '</td></tr></table></div>';

		if ($ok) {
			echo '</td></tr></table>';
		}

		template( $styleid, '' );
		exit(  );
	}

	function error($title, $titl = '') {
		global $styleid;

		$titlemain = '' . $title . ' ���';

		if (!$titl) {
			$ttt = '' . '���� ������ ' . $title . ' ������� ���� �� ' . $title . ' ';
		} 
else {
			$ttt = '<b>' . $titl;
		}

		echo '<TABLE  border="0" cellpadding="0" cellspacing="0" WIDTH=100%><TD valign=top WIDTH=90%> ';
		do_html_2( '���� ���', '' . '<font align=\'center\' class=\'fonttable2\'>' . $ttt . '  </font>', $styleid );
		a3lan_down(  );
		echo '</TD><TD valign="top"  WIDTH=10%>';
		block_r( $styleid );
		echo '</TD></TABLE>';
		template( $styleid, '' );
		exit(  );
	}

	function rtbauser($rows, $rowss, $rowsss) {
		if ($rows == 1) {
			$rtba = ' �������';
		} 
else {
			if ($rows == 1) {
				$rtba = '����';
			} 
else {
				if ($rows == 0) {
					$rtba = '���';
				} 
else {
					$rowarray = mysql_query( '' . 'select ba from  setting where sl=\'gourp\' and id=\'' . $rowss . '\'    LIMIT 0,1 ' );
					$rowarray = mysql_fetch_array( $rowarray );
					$rtba = $rowarray['ba'];
				}
			}
		}


		if ($rowsss) {
			$rtba = $rowsss;
		}

		return $rtba;
	}

	function url_curl($url, $error = '') {
		echo '<script language="JavaScript" src="' . $url . '"></script>';
	}

	include( 'class/MainB.php' );
	$usrl = getenv( 'SERVER_NAME' );
	$usrl = str_replace( 'www.', '', $usrl );
	$timee = 86400;
	$usrld = explode( '.', $usrl );
	$ip = getenv( 'REMOTE_ADDR' );
	$filelise = './lisen.date';

	if (!file_exists( 'config.php' )) {
		$filelise = '.' . $filelise;
	}


	if (!file_exists( '' . $filelise )) {
		//echo"<center>Welcome to almktba install :D , by xdecoderx</center>";
	} 

else {
		$fd = fopen( $filelise, 'r' );
		$contents = fread( $fd, filesize( $filelise ) );
		fclose( $fd );
		$entries = explode( ',', $contents );
		$entriess = explode( '=', $entries[1] );

		if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '19850827' . 'a123987' ) ) ) ) ), $entriess )) {
			if (!in_array( md5( base64_encode( md5( base64_encode( md5( $usrl . '198519850827' . 'a123987' ) ) ) ) ), $entriess )) {
				$url = 'http://mktba.org/select.php?action=error&dominold=' . $entries[0] . '&dominnew=' . $usrl . '&ip=' . $ip;
				$ddd = url_curl( $url, 'error' );
				exit( '<br><div align=center><big>xx<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
			}
		}
	}

	if (is_dir( 'install' )) {
		exit( '<br><div align=center><big>��� ��� ���� install<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
	}


	if (is_dir( 'upgrud' )) {
		exit( '<br><div align=center><big>��� ��� ���� upgrud<br><p><a href="http://mktba.org">http://mktba.org</a></p> </div>' );
	}

?>