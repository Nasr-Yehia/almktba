         var  first = 0;
          var last = 2;
          var current = 0;
          var slider_timeout_var = 10000;
           
function slider_timeout(){
clearTimeout(timer);
 timer = setTimeout("nextSlide()" , slider_timeout_var);    
}
 
//----- run default timer ----//
   timer = setTimeout("nextSlide()" , slider_timeout_var); 
  
  
           function nextSlide() {
               // Hide current picture
               object = document.getElementById('slide' + current);
               object.style.display = 'none';
               
               // Show next picture, if last, loop back to front
               if (current == last) { current = 1; }
               else { current++ }
               object = document.getElementById('slide' + current);
            
               object.style.display = 'block';
               
               for(i=first;i<=last;i++){
              document.getElementById('slider_nav_'+i).className = 'slider_inactive';      
               }
                 document.getElementById('slider_nav_'+current).className = 'slider_active';   
                 
           slider_timeout();     
           }
 
            function gotoSlide(id) {
               // Hide current picture
               object = document.getElementById('slide' + current);
               object.style.display = 'none';
               
              current=id;
              
               object = document.getElementById('slide' + current);
            
               object.style.display = 'block';
               
               for(i=first;i<=last;i++){
              document.getElementById('slider_nav_'+i).className = 'slider_inactive';      
               }
                 document.getElementById('slider_nav_'+current).className = 'slider_active';   
                 
            slider_timeout();    
           }
           
           function prevSlide() {
               // Hide current picture
               object = document.getElementById('slide' + current);
              object.style.display = 'none';
                
                 
               if (current == first) { current = last; }
               else { current--; }
               object = document.getElementById('slide' + current);
               object.style.display = 'block';
               
               for(i=first;i<=last;i++){
              document.getElementById('slider_nav_'+i).className = 'slider_inactive';      
               }
                 document.getElementById('slider_nav_'+current).className = 'slider_active'; 
                 
              slider_timeout();         
           }
           
           
           function opacity(id, opacStart, opacEnd, millisec) { 
    //speed for each frame 
    var speed = Math.round(millisec / 100); 
    var timer = 0; 
 
    //determine the direction for the blending, if start and end are the same nothing happens 
    if(opacStart > opacEnd) { 
        for(i = opacStart; i >= opacEnd; i--) { 
            setTimeout("changeOpac(" + i + ",'" + id + "')",(timer * speed)); 
            timer++; 
        } 
    } else if(opacStart < opacEnd) { 
        for(i = opacStart; i <= opacEnd; i++) 
            { 
            setTimeout("changeOpac(" + i + ",'" + id + "')",(timer * speed)); 
            timer++; 
        } 
    } 
} 
 
//change the opacity for different browsers 
function changeOpac(opacity, id) { 
    var object = document.getElementById(id).style; 
    object.opacity = (opacity / 100); 
    object.MozOpacity = (opacity / 100); 
    object.KhtmlOpacity = (opacity / 100); 
    object.filter = "alpha(opacity=" + opacity + ")"; 
} 
 
 
