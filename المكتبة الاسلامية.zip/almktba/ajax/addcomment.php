<?php
/**
* @ By xdecoderx
* www.xdecoderx.com/vb
*/         

	header( '(anti-spam-(anti-spam-(anti-spam-content-type:))) text/html;charset=windows-1256;' );
	include( '../config.php' );
	$id1 = filler( $_GET['id1'] );
	$id2 = filler( $_GET['id2'] );
	$id3 = $_GET['id3'];
	$id4 = $_GET['id4'];
	$id5 = $_GET['id5'];
	$id6 = filler( $_GET['id6'] );
	$id7 = filler( $_GET['id7'] );

	if ($id1 == 'aln3esamktba') {
		echo '  <table width="100%" dir=\'rtl\' border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#C0C0C0" >';
		echo commentshow( $id4, $id6, 2 ) . '</table>';
		$www = mysql_query( '' . 'select * from comment where idplay=\'' . $id4 . '\' and  msg=\'1\' and ( counter=1 or counter=2 ) order by id desc ' );
		$tit = mysql_num_rows( $www );
		$max = 1;
		$page = $id2;
		$num_sql = mysql_num_rows( $www );
		$pages = ceil( $num_sql / $max );
		echo '<p align=center>';
		$i = 1;

		while ($i <= $pages) {
			if ($page == $i) {
				echo '' . '    <font class=\'fonttable2\'>[ </font><font class=\'fonttable\'> ' . $i . '</font>  <font class=\'fonttable2\'>] </font>  ';
			} 
else {
				echo '' . ' <font class=\'fonttable2\'> [  </font><a class=linktable1 href=\'#showcomment\' onClick="showUser(\'showcomment\',\'aln3esamktba\',\'' . $i . '\',\'fg\',\'' . $idp . '\',\'gf\',' . $styleid . ')">' . $i . '</a>  <font class=\'fonttable2\'>]  </font>  ';
			}

			++$i;
		}


		if ($page < $pages) {
			$next = $page + 1;
			echo '' . '  <font class=\'fonttable2\'>[ </font><a class=linktable1 hhref=\'#showcomment\' onClick="showUser(\'showcomment\',\'aln3esamktba\',\'' . $next . '\',\'fg\',\'' . $idp . '\',\'gf\',' . $styleid . ')">ַבַֺבם</a>   <font class=\'fonttable2\'>]  </font> ';
		}

		echo '</p>';
		return 1;
	}


	if (( ( ( ( $id4 != $id3 || !$id6 ) || !$id1 ) || !$id2 ) || !$id6 )) {
		return 1;
	}

	$wp = mysql_query( '' . 'select * from play where id=\'' . $id5 . '\' and ctid2!=10000000 and ctid2!=10000001 ' );

	while ($row = mysql_fetch_row( $wp )) {
		$catsmktba = $row[9];
	}

	$data = time(  );
	$title = 1;
	$as = mysql_query( 'select * from  setting where id=\'1\'' );

	while ($rowss = mysql_fetch_row( $as )) {
		if (( $rowss[1] == 2 && $id6 != $id1 )) {
			$title = 3;
		}


		if ($rowss[1] == 3) {
			$title = 3;
			continue;
		}
	}

	$q2 = 'insert into comment(name,email,idplay,comment,msg,title,counter,date)values';
	$q2 .= '' . '(\'' . $id1 . '\',\'' . $id6 . '\',\'' . $id5 . '\',\'' . $id2 . '\',\'1\',\'' . $catsmktba . '\',\'' . $title . '\',\'' . $data . '\')';
	mysql_query( $q2 );
?>