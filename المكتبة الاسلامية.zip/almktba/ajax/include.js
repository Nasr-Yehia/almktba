var xmlHttp

function showUser(text,id1,id2,id3,id4,id5,id6,id7)
{
xmlHttp=GetXmlHttpObject()
if (xmlHttp==null)
{
alert ("Browser does not support HTTP Request")
return
}
var url="ajax/"+text
url=url+".php?"
url=url+"id1="+id1
url=url+"&id2="+id2
url=url+"&id3="+id3
if(id4)
{
url=url+"&id4="+id4
}
if(id5)
{
url=url+"&id5="+id5
}
if(id6)
{
url=url+"&id6="+id6
}
if(id7)
{
url=url+"&id7="+id7
}
if(text!="addvote")
{
if(text=="download"||text=="addfovuser"||text=="tab"||id2==5||id2==6||id2==3||id2==4||id2==7||id2==2)
{
xmlHttp.onreadystatechange=function(){stateChanged(text+id1)}; stateChanged();	
}else
{
xmlHttp.onreadystatechange=function(){stateChanged(text)}; stateChanged();	

}	
}else
{
xmlHttp.onreadystatechange=function(){stateChanged(text)}; stateChanged();	
	
}


xmlHttp.open("GET",url,true)	


if(xmlHttp.readyState < 4){
	if(text=="download"||text=="addfovuser"||text=="tab"||id2==5||id2==6||id2==3||id2==4||id2==7||id2==2)
{
document.getElementById(text+id1).innerHTML = '<img src="images/waiting.gif" alt="���� ���� ����������">';}else
{
document.getElementById(text).innerHTML = '<img src="images/waiting.gif" alt="���� ���� ����������">';	
}

}

xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=windows-1256");
xmlHttp.send(null)	
	


}

function stateChanged(ddd)
{

      if(xmlHttp.readyState == 4){
 
 document.getElementById(ddd).innerHTML=xmlHttp.responseText;
    }
}

function GetXmlHttpObject()
{
var xmlHttp=null;
try
 {
 // Firefox, Opera 8.0+, Safari
 xmlHttp=new XMLHttpRequest();
 }
catch (e)
 {
 //Internet Explorer
 try
  {
  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
  }
 catch (e)
  {
  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
 }
return xmlHttp;
}


    function error(teet,idp){
    if(teet!=0)
    {
     alert('����� �� ������� ���� �� ��� ���� ���');return false;   
    }else
    {
     if(window.confirm('�� ����� ��� ������')){showUser('addlinkerro',idp,'2','<?=$catsmktba?>');alert('����� �� �������');}else{return false;}   
    }	
}


var state = 'none'; 

function showhide(layer_ref) { 

if (state == 'block') { 
state = 'none'; 
} 
else { 
state = 'block'; 
} 
if (document.all) { //IS IE 4 or 5 (or 6 beta) 
eval( "document.all." + layer_ref + ".style.display = state"); 
} 
if (document.layers) { //IS NETSCAPE 4 or below 
document.layers[layer_ref].display = state; 
} 
if (document.getElementById &&!document.all) { 
hza = document.getElementById(layer_ref); 
hza.style.display = state; 
} 
} 
