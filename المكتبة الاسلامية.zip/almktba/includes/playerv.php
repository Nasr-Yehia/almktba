<?php

 if ( @eregi( "playerv.php",$_SERVER["PHP_SELF"] ) )
{
    header( "Location: ../index.php" );
    exit( );
}
include('player.php');
if(strlen($comment)>11)
{
if(ereg("audio/x-pn-realaudio-plugin",$comment))
{
$comment="realplayer";		
mysql_query("UPDATE play SET comment='$comment' where id='$idp'");
}
if(ereg("windows/windowsmedia/download",$comment))
{
$comment="mediaplayer";		
mysql_query("UPDATE play SET comment='$comment' where id='$idp'");
}

if(ereg("youtube.com",$comment))
{
$comment="youtube";		
mysql_query("UPDATE play SET comment='$comment' where id='$idp'");
}

if(ereg("googleplayer",$comment))
{
$comment="google";		
mysql_query("UPDATE play SET comment='$comment' where id='$idp'");
}


if(ereg("width: 450px; height: 289px",$comment))
{
$comment="flashplayer";		
mysql_query("UPDATE play SET comment='$comment' where id='$idp'");
}
}

if($comment=="realplayer"){   $playerurl=playrmvideo($url);}
elseif($comment=="mediaplayer"){$playerurl=playmediavideo($url);}
elseif($comment=="youtube"){
if(!ereg("youtube.com",$url))
{
$url="http://www.youtube.com/watch?v=".$url;
}
$playerurl=playyoutube($url);}
elseif($comment=="google"){$playerurl=playgoogle("http://video.google.com/googleplayer.swf?docId=".$url);}
elseif($comment=="flashplayer"){$playerurl=playflv($url);}
if(!$comment)
{
$type=explode(".",$url);
$extens=strtolower($type[count($type)-1]);
if($extens=='wmv' || $extens=='avi'|| $extens=='mpeg'|| $extens=='mpg'){
	$playerurl=playmediavideo($url);
}
if($extens=='rm' || $extens=='ra'|| $extens=='rmvb'|| $extens=='ram'){

$playerurl=playrmvideo($url);
}
if($extens=='flv' ){
$playerurl=playflv($url);
}

if( $extens=='swf'){
$playerurl=playswf($url);
}	
if(ereg("youtube.com",$url))
{
$playerurl=playyoutube($url);
}

}


?>