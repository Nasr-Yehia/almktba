<?php
if ( @eregi( "linkat.php",$_SERVER["PHP_SELF"] ) )
{
    header( "Location: ../index.php" );
    exit( );
}
$qlink=mysql_query("select * from linkat where catsmktba='{$id}'   and  visible != 2 ORDER BY `order` ASC ");
if($qlink)
{
   echo '<table border="0"  cellspacing="1" cellpadding="6" width="100%" align="center" style="direction: '.$dir2.'">
	<tr  style="height: 20px">
		<td  colspan="5" class="tcat" style="height: 20px">'.$Lag[linksadd].'</td>
	
	</tr>    <tr>  <td class="thead"  ></td> 
	<td class="thead" width="60%" > '.$Lag[linkname].'</td><td  class="thead" width="20%">'.$Lag[linkselect].'</td>
    <td  class="thead"width="25%">'.$Lag[download].'</td>	</tr> '; 
while($linkrow=mysql_fetch_array($qlink))
{
$target_link_ext = $linkrow[4];
$indirlink = $linkrow[4];
$linkrow4 =trim( strtolower($linkrow[4]));
$extension = substr(strrchr($linkrow4, '.'), 1);

if((($extension  == "rm" ||   $extension=="rpm") &&$linkrow[8]=="" )||$linkrow[8]=="rmplayer")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=rm','window','width=400,height=190,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img  alt src='images/icons/listen.png'   border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif((( $extension  == "mp3" ||  $extension  == "wma" )  &&$linkrow[8]=="" ) ||$linkrow[8]=="mp3player")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=mp3','window','width=400,height=190,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img  alt src='images/icons/listen.png'  border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif( (($extension  == "png"||  $extension  == "gif"|| $extension == "jpg"|| $extension == "jpeg"|| $extension == "bmp"|| $extension == "tif"|| $extension == "tiff" )  &&$linkrow[8]==""  ) ||$linkrow[8]=="image")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=img','window','width=550,height=560,toolbar=yes,directories=no,status=yes,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img  src='images/icons/viewi.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif((($extension == "ram" ||  $extension == "rmvb" ||  $extension == "ra" ||  $extension == "3gp" ||strstr($linkrow4,'www.way2allah.com') )  &&$linkrow[8]==""   ) ||$linkrow[8]=="rlplayer")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=vidr','window','width=410,height=460,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img src='images/icons/view.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif( (( $extension == "avi"  ||  $extension == "wmv" || $extension == "mp2" ||    $extension == "mp4"||    $extension == "asf" ||   $extension == "ogv" ||   $extension == "asf" ||  $extension == "aac" ||  $extension == "mpg"||  $extension == "mpeg" )  &&$linkrow[8]==""   )||$linkrow[8]=="mdplayer")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=vidw','window','width=410,height=460,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img src='images/icons/view.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif(((strstr($linkrow4,'video.google.com'))  && $linkrow[8]==""  ) ||$linkrow[8]=="glplayer"  )
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=vidg','window','width=500,height=510,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img src='images/icons/view.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif(((strstr($linkrow4,'www.youtube.com'))  && $linkrow[8]==""  ) ||$linkrow[8]=="ytplayer"  )
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=vidy','window','width=500,height=510,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img src='images/icons/view.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif( (($extension == "flv" )  && $linkrow[8]==""   )||$linkrow[8]=="flvplayer" )
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=flv','window','width=500,height=510,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img src='images/icons/view.png' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif(( $extension == "swf"  && $linkrow[8]=="") || $linkrow[8]=="swfplayer"  )
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=swf','window','width=500,height=510,toolbar=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img  alt src='images/icons/view.png'   border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
elseif($linkrow[8]=="word")
{
$viewlink ="<a class='linktable' href=\"#\" onclick=\"window.open('playa.php?catsmktba=$catsmktba&&row=$linkrow[0]&&pl=word','window','width=800,height=600,toolbar=yes,directories=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes');\" > <font class='fonttable'></font>&nbsp;<img height='22' alt src='images/icons/read.png'  width='22' border='0' >&nbsp;<font class='fonttable2'> </font></a>";
}
else
{
$viewlink ="&nbsp;<img height='15' alt src='images/icon_tell.gif' width='16' > &nbsp;<font class='fonttable'>$lag_addition_link</font><font class='fonttable2'> </font>";
}


$downloadcounter    = $linkrow[7];

if( $linktype != 2){
$downloadcounter    =NULL; 
$lag_download_count =NULL; 
$td_download        =NULL;
}else{
$lag_download_count = $lag_download_count_new; 
$td_download = " <td align='center' width='111'><table dir='$dir2'>
        <tr><td><font class='fonttable2'>$lag_download_count</font>&nbsp;&nbsp; </td><td><font class='fonttable'> $downloadcounter </font> &nbsp;
</td></tr> </table> </td> ";   
}    
if($r3232==1)
{
echo  "<tr   class='alt2'>";
$r3232=0;
}
else
{
echo  "<tr   class='alt1'>";
$r3232=1;
}

echo " 
<td align='$align'  style='height: 35px;'>
<img  id=\"forum_statusicon_23\" border=\"0\" backtd=\"\"   src='images/icons/player/$linkrow[8].png' >
</td>
$td_download
<td  align='$align'>
<font class='fonttable'><a href='".$indirlink."' target='".$target_link_ext."'  'class='linktable'>".$linkrow[3]."</a></font><font class='fonttable'></font><font class='fonttable'></font><font class='fonttable2'></font>&nbsp;</td>
 <td  align='center'>".$viewlink." </td>
<td align='center'>
<a href='".$indirlink."' target='".$target_link_ext."'  'class='linktable'><img  id=\"forum_statusicon_23\" border=\"0\"  src='images/icons/download.png' > </a></td>
</tr>";
}
echo  "</table>";
}




?>