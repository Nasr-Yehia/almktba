<?php

/**
 * @author 
 * @copyright 2010
 */

if ( @eregi( "player.php",$_SERVER["PHP_SELF"] ) )
{
    header( "Location: ../index.php" );
    exit( );
}

function playmp3($url){

      
      $file='<OBJECT ID=MediaPlayer CLASSID="CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6" STANDBY="Loading MicroSoft Windows Media Player components..." 	TYPE="application/x-oleobject" WIDTH="90%" HEIGHT="64">	<PARAM name="url" value="'.$url.'"><PARAM NAME="animationatStart" VALUE="true"><PARAM NAME="transparentatStart" VALUE="true"><PARAM NAME="autoStart" VALUE="true"><PARAM NAME="showControls" VALUE="true"><PARAM NAME="ShowDisplay" VALUE="true"><EMBED TYPE="application/x-mplayer2"   src="'.$url.'"  NAME="MediaPlayer"  CONTROLS="ControlPanel,StatusBar" HEIGHT="64"  WIDTH="90%" AUTOSTART="true">  </EMBED></OBJECT>';

///$file='               <object type="application/x-shockwave-flash" data="includes/mp3player/player.swf" id="30338" height="24" width="290">                <param name="movie" value="includes/mp3player/player.swf"><param name="FlashVars" value="id=30338&soundFile='.$url.'&titles='.$nameplay.'"><param name="quality" value="high"> <param name="autostart" value="true">             <param name="menu" value="false">                <param name="wmode" value="transparent">                </object>';
      return $file;
}


function playrmvoice($url)
{

$file='<embed  height="60" type="audio/x-pn-realaudio-plugin" pluginspage="http://www.real.com/player"  WIDTH="90%" src="'.$url.'" border="0" hspace="0" vspace="0" controls="controlpanel,statusbar" maintainaspect="false" autostart="true" nojava="true"  />';
return $file;
}


function playmediavideo($url)
{
$file='<p align="center">      <OBJECT id="mediaPlayer" width="320" height="285"      classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95"      codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701"      standby="Loading Microsoft Windows Media Player components..." type="application/x-oleobject">      <param name="fileName" value="'.$url.'">      <param name="animationatStart" value="true">      <param name="transparentatStart" value="true">      <param name="autoStart" value="true">      <param name="showControls" value="true">      <param name="loop" value="false">      <EMBED type="application/x-mplayer2"        pluginspage="http://microsoft.com/windows/mediaplayer/en/download/"        id="mediaPlayer" name="mediaPlayer" displaysize="4" autosize="-1"        bgcolor="darkblue" showcontrols="true" showtracker="-1"        showdisplay="0" showstatusbar="-1" videoborder3d="-1" width="320" height="285"        src="'.$url.'" autostart="true" designtimesp="5311" loop="false">      </EMBED>      </OBJECT>       </p> ';
 return $file;
}




function playrmvideo($url)
{
$file='<div align="center"   width="320" height="240">        <OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA"        width="320" height="240">        <param name="src" value="'.$url.'">        <param name="autostart" value="true">        <param name="controls" value="imagewindow">        <param name="console" value="video">        <param name="loop" value="false">        <EMBED src="'.$url.'" width="320" height="240"        loop="false" type="audio/x-pn-realaudio-plugin" controls="imagewindow" CONSOLE="'.$url.'" autostart="true" >        </EMBED>        </OBJECT><OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA"          width="320" height="30">          <param name="src" value="'.$url.'">          <param name="autostart" value="true">          <param name="controls" value="ControlPanel">          <param name="console" value="video">          <EMBED src="'.$url.'" width="320" height="61"          controls="ControlPanel,statusbar" type="audio/x-pn-realaudio-plugin" CONSOLE="'.$url.'" autostart="true">          </EMBED>          </OBJECT>        <div>';
 return $file;
}


function playflv($url)
{
$file='<div id="container"></div><script type="text/javascript">var s1 = new SWFObject("ajax/playeryoutube/mediaplayer.swf","mediaplayer","480","385","8");s1.addParam("allowfullscreen","true");s1.addVariable("autostart","true");s1.addVariable("width","480");s1.addVariable("height","385");s1.addVariable("file","'.$url.'");s1.addParam("menu","false");s1.write("container");</script>';
 return $file;
}




function playswf($url)
{
$file="<object classid='clsid:D27CDB6E-AE6D-11CF-96B8-444553540000' id='obj1' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0' border='0' width='500' height='400'>     <param name='movie' value='$url'>   <param name='quality' value='High'>    <param name='scale' value='ShowAll'>   <embed src='$url' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' name='obj1' width='500' height='400' quality='High' scale='ShowAll'></object>";
   return $file;
}


function playgoogle($url)
{

$file="<embed id=VideoPlayback src=$url&hl=en&fs=true style=width:400px;height:326px allowFullScreen=true allowScriptAccess=always type=application/x-shockwave-flash> </embed>";
return $file;
}

function youtube_correct($urlp){
    if(strstr($urlp,'www.youtube.com') &&strstr($urlp,'watch?v=')){
        $urlp =  str_replace("watch?v=","v/",$urlp);
    }else{
      $urlp;
    }
    return $urlp;
}

function playyoutube($url)
{

$file='<div id="container"></div><script type="text/javascript">var s1 = new SWFObject("ajax/playeryoutube/mediaplayer.swf","mediaplayer","480","385","8");s1.addParam("allowfullscreen","true");s1.addVariable("autostart","true");s1.addVariable("width","480");s1.addVariable("height","385");s1.addVariable("file","'.$url.'");s1.addParam("menu","false");s1.write("container");</script>';




 return $file;
}




?>