<?php

/**
 * @author 
 * @copyright 2010
 */
 if ( @eregi( "players.php",$_SERVER["PHP_SELF"] ) )
{
    header( "Location: ../index.php" );
    exit( );
}
function checkext_extrass($urlp)
{

global $nameplay;
$type=explode(".",$urlp);
$extens=strtolower($type[count($type)-1]);
if($extens=='wma' || $extens=='mp3'){
$playfile='<OBJECT ID=MediaPlayer CLASSID="CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6" STANDBY="Loading MicroSoft Windows Media Player components..." 	TYPE="application/x-oleobject" WIDTH="90%" HEIGHT="64">	<PARAM name="url" value="'.$urlp.'"><PARAM NAME="animationatStart" VALUE="true"><PARAM NAME="transparentatStart" VALUE="true"><PARAM NAME="autoStart" VALUE="true"><PARAM NAME="showControls" VALUE="true"><PARAM NAME="ShowDisplay" VALUE="true"><EMBED TYPE="application/x-mplayer2"   src="'.$urlp.'"  NAME="MediaPlayer"  CONTROLS="ControlPanel,StatusBar" HEIGHT="64"  WIDTH="90%" AUTOSTART="true">  </EMBED></OBJECT>';

if ( $_SESSION['stylejawal']=="ok" or preg_match('/(android|xda |xda_)/i', $_SERVER['HTTP_USER_AGENT'])) {$playfile='               <object type="application/x-shockwave-flash" data="includes/mp3player/player.swf" id="30338" height="24" width="290">                <param name="movie" value="includes/mp3player/player.swf"><param name="FlashVars" value="id=30338&soundFile='.$urlp.'&titles='.$nameplay.'"><param name="quality" value="high"> <param name="autostart" value="true">             <param name="menu" value="false">                <param name="wmode" value="transparent">                </object>';
}

//$playfile='  <SCRIPT type=text/javascript src="includes/mp3player/swfobject2.js"></SCRIPT> <SCRIPT type=text/javascript>var s1 = new SWFObject("includes/mp3player/player2.swf","mpl","99%","24","1");s1.addParam("allowfullscreen","true"); s1.addParam("allowscriptaccess","always");s1.addVariable("autostart","false");s1.addVariable("file","{image}");s1.write("preview"); </SCRIPT>';

}
elseif($extens=='ram'||$extens=='rm'||$extens=='ra'){$playfile='<embed  height="60" type="audio/x-pn-realaudio-plugin" pluginspage="http://www.real.com/player"  WIDTH="90%" src="'.$urlp.'" border="0" hspace="0" vspace="0" controls="controlpanel,statusbar" maintainaspect="false" autostart="true" nojava="true"  />';}
elseif( empty($urlp)||$urlp==""||!$urlp || $urlp==null ){ $playfile = null;}

return ($playfile );
}
$playerurl=checkext_extrass($url);
$playerimage=checkext_extrass($image);
if($comm1)
{
include('player.php');
$type=explode(".",$comm1);
$extens=strtolower($type[count($type)-1]);
if($extens=='wmv' || $extens=='avi'|| $extens=='mpeg'|| $extens=='mpg'|| $extens=='mp4'){
$playercomm1=playmediavideo($comm1);
}
if($extens=='rm' || $extens=='ra'|| $extens=='rmvb'|| $extens=='ram'){
$playercomm1=playrmvideo($comm1);
}
if($extens=='flv' ){
$playercomm1=playflv($comm1);
}

if( $extens=='swf'){
$playercomm1=playswf($comm1);
}	
if(ereg("youtube.com",$comm1))
{
$playercomm1=playyoutube($comm1);
}    
}
?>